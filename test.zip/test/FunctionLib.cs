﻿using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 直线检测
{
    class FunctionLib
    {

        private void CollectionLight_Click(object sender, EventArgs e)
        {
            _XYStruct _XYSetStruct = new _XYStruct();
            Point StartPoint = new Point();
            Point EndPoint = new Point();
            int Width = _CuringPictrue.Width;
            int Height = _CuringPictrue.Height;
            int mind = Math.Max(Width, Height);
            double Y = 0;
            double[] ResultArray = new double[Width];
            Dictionary<double, _XYStruct> SaveXY = new Dictionary<double, _XYStruct>();
            double Diagonal = Math.Sqrt(Width * Width + Height * Height);
            int DiagonalInt = Convert.ToInt32(Diagonal);
            double[][] TempArray = new double[DiagonalInt + mind][];

            for (int i = 0; i < TempArray.Length; i++)//建立数组第二维
            {
                TempArray[i] = new double[180];
            }
            for (int i = 0; i < TempArray.Length; i++)//初始化数组
            {
                for (int k = 0; k < 180; k++)
                {
                    TempArray[i][k] = 0;
                }
            }
            List<Point> Collections = new List<Point>();
            FunctionLib fun = new FunctionLib();
            Collections = fun.HighLightPoint(_CuringPictrue);
            TempArray = fun.polar_coordinates(Collections, _CuringPictrue);
            SaveXY = fun.MaxHough(TempArray, 100, _CuringPictrue);
            FileStream fs = File.Create(@"E:/XY.txt");
            StreamWriter sw = new StreamWriter(fs);

            foreach (var item in SaveXY)
            {
                if (pictureBox2.Image != null)
                {
                    Bitmap SaveCannyPic = new Bitmap(pictureBox2.Image);
                    SaveCannyPic.Save("E:\\CannyResultPic.bmp");
                }
                for (int i = 0; i < Width; i++)//这里的i实际上市图片中的x
                {
                    Y = item.Value.SetK * i + item.Value.SetB;
                    int _IntY = Convert.ToInt32(Y);
                    if (_IntY >= 0)
                    {
                        ResultArray[i] = Y;
                    }
                }
                if (item.Value.SetK == 0)
                {
                    StartPoint.X = 0;
                    StartPoint.Y = Convert.ToInt32(item.Value.SetB);
                    EndPoint.X = Width;
                    EndPoint.Y = Convert.ToInt32(item.Value.SetB);
                    break;
                }
                if (item.Value.SetK == double.NaN)
                {
                    StartPoint.X = Convert.ToInt32(item.Value.SetB);
                    StartPoint.Y = 0;
                    EndPoint.X = Convert.ToInt32(item.Value.SetB);
                    EndPoint.Y = Height;
                    break;
                }

                for (int i = 0; i < ResultArray.Length; i++)
                {
                    if (ResultArray[i] > 0 && ResultArray[i] < Height)
                    {
                        StartPoint.X = i;
                        StartPoint.Y = Convert.ToInt32(ResultArray[i]);
                        break;
                    }
                }
                if (item.Value.SetK > 0)
                {

                    if (ResultArray[ResultArray.Length - 1] <= Height)
                    {
                        EndPoint.X = Width - 1;
                        EndPoint.Y = Convert.ToInt32(ResultArray[ResultArray.Length - 1]);
                    }
                    else
                    {
                        for (int i = 0; i < ResultArray.Length; i++)
                        {
                            if (ResultArray[i] <= Height && ResultArray[i + 1] >= Height)
                            {
                                EndPoint.X = i;
                                EndPoint.Y = Convert.ToInt32(ResultArray[i]);
                                break;
                            }
                        }
                    }

                }
                else if (item.Value.SetK < 0)//K小于0是
                {
                    if (ResultArray[ResultArray.Length - 1] >= 0)
                    {
                        EndPoint.X = Width - 1;
                        EndPoint.Y = Convert.ToInt32(ResultArray[ResultArray.Length - 1]);
                    }
                    else
                    {
                        for (int i = 0; i < ResultArray.Length; i++)
                        {
                            if (ResultArray[i] >= 0 && ResultArray[i + 1] <= 0)
                            {
                                EndPoint.X = i;
                                EndPoint.Y = Convert.ToInt32(ResultArray[i]);
                                break;
                            }
                        }
                    }
                }
                Image<Rgb, byte> DrawImage = new Image<Rgb, byte>(@"E:\CannyResultPic.bmp");
                DrawImage.Draw(new LineSegment2D(StartPoint, EndPoint), new Rgb(255, 0, 0), 3);
                pictureBox2.Image = null;
                pictureBox2.Image = DrawImage.ToBitmap();

                //sw.WriteLine("K = {0},B = {1}",item.X,item.Y);
            }

            sw.Close();
            fs.Close();
        }


        public unsafe List<Point> HighLightPoint(Image<Gray, byte> Img)
        {

            List<Point> PointList = new List<Point>();
            byte* pData = (byte*)Img.MIplImage.imageData;
            int WidthStep = Img.MIplImage.widthStep;
            int Width = Img.MIplImage.width;
            int Height = Img.MIplImage.height;
            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Height; j++)
                {
                    if (pData[j * WidthStep + i] == 255)
                    {
                        Point p = new Point();
                        p.X = i;
                        p.Y = j;
                        PointList.Add(p);
                    }
                }
            }
            return PointList;
        }
        
        /// <summary>
        ///  √||x^2 + y^2|| = r  ,  1/tan(y/x) = θ ，进行极坐标系换算,使用累加器计算点数最多的(ρ,θ)
        /// </summary>
        /// <param name="HeightLightPoint"></param>
        /// <returns></returns>
        public unsafe double[][] polar_coordinates(List<Point> HeightLightPoint, Image<Gray, byte> CannyImage)
        {
            int tp = 0;
            int Width = CannyImage.Width;
            int Height = CannyImage.Height;
            int mind = Math.Max(Width, Height);

            FileStream fs = File.Create(@"E:/test.txt");
            StreamWriter sw = new StreamWriter(fs);
            double[] sin_value = new double[180];
            double[] cos_value = new double[180];
            for (int i = 0; i < 180; i++)
            {
                sin_value[i] = Math.Sin(i * 3.1415926 / 180);
                cos_value[i] = Math.Cos(i * 3.1415926 / 180);
            }
            double Diagonal = Math.Sqrt(Width * Width + Height * Height);
            int DiagonalInt = Convert.ToInt32(Diagonal);
            double DiagonalInt1 = DiagonalInt;
            DiagonalInt = Convert.ToInt32(DiagonalInt1);

            double[][] PolarCoordinatesArray = new double[DiagonalInt + mind][];

            for (int i = 0; i < PolarCoordinatesArray.Length; i++)//建立数组第二维
            {
                PolarCoordinatesArray[i] = new double[180];
            }
            for (int i = 0; i < PolarCoordinatesArray.Length; i++)//初始化数组
            {
                for (int k = 0; k < 180; k++)
                {
                    PolarCoordinatesArray[i][k] = 0;
                }
            }
            List<int> Int_List = new List<int>();
            foreach (Point item in HeightLightPoint)
            {

                int x = item.X;
                int y = item.Y;
                for (int i = 0; i < 180; i++)
                {
                    tp = (int)(x * cos_value[i] + y * sin_value[i]) + mind;//计算每个角度的ρ
                    PolarCoordinatesArray[tp][i] += 1;

                    //sw.WriteLine(tp+"\n");
                    Int_List.Add(tp);
                }

            }
            for (int i = 0; i < PolarCoordinatesArray.Length; i++)
            {
                for (int k = 0; k < PolarCoordinatesArray[i].Length; k++)
                {
                    int temp = 0;
                    temp = i - mind;
                    sw.WriteLine("ρ=" + temp + "\tθ=" + k + "\t" + PolarCoordinatesArray[i][k]);
                }
            }
            sw.Close();
            fs.Close();
            return PolarCoordinatesArray;
        }


        /// <summary>
        /// 查找累加器中大于阈值的(ρ,θ),并且将他们存储在hashtable集合中。
        /// </summary>
        /// <returns></returns>
        public Dictionary<double, _XYStruct> MaxHough(double[][] PolarCoordinatesArray, int MaxHoughThreshold, Image<Gray, byte> CannyImage)
        {
            double B, K;
            int Width = CannyImage.Width;
            int Height = CannyImage.Height;
            int mind = Math.Max(Width, Height);
            _XYStruct _XYSetStruct = new _XYStruct();
            Dictionary<double, Point> DictoryList_SortedByKey = new Dictionary<double, Point>();
            Point KBPoint = new Point();
            List<Point> PolarPointList = new List<Point>();//创建存储(K,B)坐标点的集合
            Dictionary<double, Point> DictoryList = new Dictionary<double, Point>();//用来存储(ρ,θ)坐标点
            Dictionary<double, _XYStruct> KBList = new Dictionary<double, _XYStruct>();
            int CountNumber = 0;
            for (int i = 0; i < PolarCoordinatesArray.Length; i++)
            {
                for (int k = 0; k < PolarCoordinatesArray[i].Length; k++)
                {
                    if (PolarCoordinatesArray[i][k] > MaxHoughThreshold)//i是ρ，k是θ
                    {
                        if (CountNumber <3)//当连续的大于数据的
                        {
                            double temp = PolarCoordinatesArray[i][k];
                            Point PolarPoint = new Point();//创建坐标点
                            PolarPoint.X = i-mind;//存储极大值的ρ
                            PolarPoint.Y = k;//存储极大值的θ
                            if (DictoryList.ContainsKey(PolarCoordinatesArray[i][k]))
                            {
                                continue;
                            }
                            else
                            {
                                //将极坐标(ρ,θ)数据添加到合集中
                                DictoryList.Add(PolarCoordinatesArray[i][k], PolarPoint);//把极大值的坐标存储到DictoryList集合当中，用当前直线上的点数作为Key，将对应参数坐标系中的(ρ,θ)作为值
                                //进行对应存储
                            }

                            CountNumber++;
                        }
                        else
                        {
                            CountNumber = 0;
                            EliminatePoint(i,k,ref PolarCoordinatesArray);
                            DictoryList_SortedByKey = DictoryList.OrderByDescending(p => p.Key).ToDictionary(p => p.Key, o => o.Value);//对hashtable中的Key进行降序排序
                            _PolarToXY(DictoryList_SortedByKey,CannyImage,out B,out K);
                            DictoryList_SortedByKey.Clear();//清除当前的极大值点
                            _XYSetStruct.SetK = K;
                            _XYSetStruct.SetB = B;
                            KBList.Add(i,_XYSetStruct);//将计算得到的K,B存储到Dictionary集合中和,K是key,B是value。
                            //PolarPointList.Add(KBPoint);//将(k,b)添加到链表集合当中去
                        }
                    }
                }
            }
            return KBList;
        }

        public void _PolarToXY(Dictionary<double, Point> DictoryList_SortedByKey ,Image<Gray, byte> CannyImage, out double B ,out double K)
        {
            List<Point> SavePoint = new List<Point>();
            Point AccumulateData = new Point();
            Point StartPoint = new Point();
            Point EndPoint = new Point();
            double y = 0L;
            int length = 0;
            int theta = 0;
            int Width = CannyImage.Width;
            int Height = CannyImage.Height;
            double MedianIndex = 0L;
            double[] ResultArray = new double[Width];//创建一个用于存储x,y对应关系的矩阵。
            for (int i = 0; i < ResultArray.Length; i++)
            {
                ResultArray[i] = 0;
            }
            List<double> DictoryIndex = new List<double>();
            foreach (var item in DictoryList_SortedByKey)
            {
                DictoryIndex.Add(item.Key);
            }
            DictoryIndex.Sort();
            //int DictoryCount = 0;//设置中间值，使用中间值进行定位，确保数据不会太大。
            //if (DictoryIndex.Count%2 != 0 )
            //{
            //    DictoryCount = DictoryIndex.Count + 1;
            //}
            MedianIndex = DictoryIndex[0];
            AccumulateData = DictoryList_SortedByKey[MedianIndex];//获取筛选出来的,Point.X = ρ, Point.Y = θ
            theta = AccumulateData.Y;
            length = AccumulateData.X;
            B = length / Math.Sin(theta * Math.PI / 180);//算取直角坐标系的截距
            K = -Math.Cos(theta * Math.PI / 180) / Math.Sin(theta * Math.PI / 180);//算取直角坐标系的斜率

        }

        public void EliminatePoint(int x,int y, ref double[][] PolarCoordinatesArray)
        {

            for (int i = x-20; i < x+20; i++)
            {
                for (int j = y-20; j < y+20; j++)
                {
                    if (j==180)
                    {
                        j = 179;
                    }
                    PolarCoordinatesArray[i][j] = 0;
                }
            }
        }
        public struct _XYStruct
        {
            private double K;
            private double B;
            
            public double SetK
            {
                get { return K; }
                set { K = value; }
            }
            public double SetB
            {
                get { return B; }
                set { B = value; }
            }
        }
    }
}
