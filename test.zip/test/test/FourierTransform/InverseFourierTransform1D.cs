﻿using System;
namespace test.FourierTransform
{
    public class OneDimensionInverseFourierTransform
    {
        public OneDimensionInverseFourierTransform()
        {
        }
    }
}