﻿using System;
namespace test.FourierTransform
{
    public class OneDimensionFourierTransform
    {
        public OneDimensionFourierTransform()
        {
        }
    }
}
