﻿using System;
namespace test.FourierTransform
{
    public class ImageFourierTransform
    {
        public ImageFourierTransform()
        {
        }

    }
}
