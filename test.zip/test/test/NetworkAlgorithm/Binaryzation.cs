﻿using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace test.NetworkAlgorithm
{
    public class Binaryzation
    {
        public Binaryzation()
        {
        }

        private unsafe void GetHistGram(Bitmap Src, int[] HistGram)
        {
            BitmapData SrcData = Src.LockBits(new Rectangle(0, 0, Src.Width, Src.Height), ImageLockMode.ReadWrite, Src.PixelFormat);
            int Width = SrcData.Width, Height = SrcData.Height, SrcStride = SrcData.Stride;
            byte* SrcP;
            for (int Y = 0; Y < 256; Y++) HistGram[Y] = 0;
            for (int Y = 0; Y < Height; Y++)
            {
                SrcP = (byte*)SrcData.Scan0 + Y * SrcStride;
                for (int X = 0; X < Width; X++, SrcP++) HistGram[*SrcP]++;
            }
            Src.UnlockBits(SrcData);
        }


        /// <summary>
        /// 获得二值化阈值。
        /// </summary>
        /// <returns>The huang fuzzy threshold.</returns>
        /// <param name="HistGram">Hist gram.</param>
        public static int GetHuangFuzzyThreshold(int[] HistGram)
        {
            int X, Y;
            int First, Last;
            int Threshold = -1;
            double BestEntropy = Double.MaxValue, Entropy;
            //   找到第一个和最后一个非0的色阶值
            for (First = 0; First < HistGram.Length && HistGram[First] == 0; First++) ;
            for (Last = HistGram.Length - 1; Last > First && HistGram[Last] == 0; Last--) ;
            if (First == Last) return First;                // 图像中只有一个颜色
            if (First + 1 == Last) return First;            // 图像中只有二个颜色

            // 计算累计直方图以及对应的带权重的累计直方图
            int[] S = new int[Last + 1];
            int[] W = new int[Last + 1];            // 对于特大图，此数组的保存数据可能会超出int的表示范围，可以考虑用long类型来代替
            S[0] = HistGram[0];
            for (Y = First > 1 ? First : 1; Y <= Last; Y++)
            {
                S[Y] = S[Y - 1] + HistGram[Y];
                W[Y] = W[Y - 1] + Y * HistGram[Y];
            }

            // 建立公式（4）及（6）所用的查找表
            double[] Smu = new double[Last + 1 - First];
            for (Y = 1; Y < Smu.Length; Y++)
            {
                double mu = 1 / (1 + (double)Y / (Last - First));               // 公式（4）
                Smu[Y] = -mu * Math.Log(mu) - (1 - mu) * Math.Log(1 - mu);      // 公式（6）
            }

            // 迭代计算最佳阈值
            for (Y = First; Y <= Last; Y++)
            {
                Entropy = 0;
                int mu = (int)Math.Round((double)W[Y] / S[Y]);             // 公式17
                for (X = First; X <= Y; X++)
                    Entropy += Smu[Math.Abs(X - mu)] * HistGram[X];
                mu = (int)Math.Round((double)(W[Last] - W[Y]) / (S[Last] - S[Y]));  // 公式18       
                for (X = Y + 1; X <= Last; X++)
                    Entropy += Smu[Math.Abs(X - mu)] * HistGram[X];       // 公式8
                if (BestEntropy > Entropy)
                {
                    BestEntropy = Entropy;      // 取最小熵处为最佳阈值
                    Threshold = Y;
                }
            }
            return Threshold;
        }


    }
}
