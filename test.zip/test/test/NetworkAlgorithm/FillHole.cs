﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace test.NetworkAlgorithm
{
    public class FillHole
    {
        public FillHole()
        {
        }

        /// <summary>
        /// 网络孔隙填充算法，单通道灰度图输入。
        /// </summary>
        /// <param name="Src">Source.</param>
        /// <param name="FillBackGround">If set to <c>true</c> fill back ground.</param>
        public unsafe void FillHoleAlgorithm(Bitmap Src, bool FillBackGround = false)
        {

            int X, Y;
            int Width, Height, Stride;
            byte* Pointer, Scan0;
            BitmapData SrcData = Src.LockBits(new Rectangle(0, 0, Src.Width, Src.Height), ImageLockMode.ReadWrite, Src.PixelFormat);

            Width = SrcData.Width; 
            Height = SrcData.Height; 

            Scan0 = (byte*)SrcData.Scan0; 
            Stride = SrcData.Stride;

            byte Color;
            if (FillBackGround == false)
                Color = 255;
            else
                Color = 0;


            for (Y = 0; Y < Height; Y++)
            {
                Pointer = Scan0 + Y * Stride;
                if (Pointer[0] == Color) FloodFill(Src, Scan0, Stride, new Point(0, Y), 127);
                if (Pointer[Width - 1] == Color) FloodFill(Src, Scan0, Stride, new Point(Width - 1, Y), 127);
            }

            for (X = 0; X < Width; X++)
            {
                Pointer = Scan0 + X;
                if (Pointer[0] == Color) FloodFill(Src, Scan0, Stride, new Point(X, 0), 127);
                if (Pointer[(Height - 1) * Stride] == Color) FloodFill(Src, Scan0, Stride, new Point(X, Height - 1), 127);
            }

            for (Y = 0; Y < Height; Y++)
            {
                Pointer = Scan0 + Y * Stride;
                for (X = 0; X < Width; X++)
                {
                    if (Pointer[X] == 127)
                        Pointer[X] = Color;
                    else
                        Pointer[X] = (byte)(255 - Color);
                }
            }

            Src.UnlockBits(SrcData);
        }

        /// <summary>
        /// 对掩码进行FloodFill操作。
        /// </summary>
        /// <param name="Src">Source.</param>
        /// <param name="ptr">Ptr.</param>
        /// <param name="Stride">Stride.</param>
        /// <param name="location">Location.</param>
        /// <param name="FillValue">Fill value.</param>
        public unsafe void FloodFill(Bitmap Src, byte* ptr, int Stride, Point location, byte FillValue)
        {

            int w = Src.Width;
            int h = Src.Height;
            int PickColor;
            Stack<Point> fillPoints = new Stack<Point>(w * h);

            int bytes = Stride * Src.Height;
            byte[] grayValues = new byte[bytes];
            System.Runtime.InteropServices.Marshal.Copy((IntPtr)ptr, grayValues, 0, bytes);
            byte[] temp = (byte[])grayValues.Clone();

            PickColor = ptr[Stride * location.Y + location.X];

            if (location.X < 0 || location.X >= w || location.Y < 0 || location.Y >= h) return;
            fillPoints.Push(new Point(location.X, location.Y));
            int[,] mask = new int[w, h];

            while (fillPoints.Count > 0)
            {
                Point p = fillPoints.Pop();
                mask[p.X, p.Y] = 1;
                temp[p.X + p.Y * Stride] = FillValue;

                if (p.X > 0 && temp[(p.X - 1) + p.Y * Stride] == PickColor)
                {
                    temp[(p.X - 1) + p.Y * Stride] = FillValue;
                    fillPoints.Push(new Point(p.X - 1, p.Y));
                    mask[p.X - 1, p.Y] = 1;
                }
                if (p.X < w - 1 && temp[(p.X + 1) + p.Y * Stride] == PickColor)
                {
                    temp[(p.X + 1) + p.Y * Stride] = FillValue;
                    fillPoints.Push(new Point(p.X + 1, p.Y));
                    mask[p.X + 1, p.Y] = 1;
                }
                if (p.Y > 0 && temp[p.X + (p.Y - 1) * Stride] == PickColor)
                {
                    temp[p.X + (p.Y - 1) * Stride] = FillValue;
                    fillPoints.Push(new Point(p.X, p.Y - 1));
                    mask[p.X, p.Y - 1] = 1;
                }
                if (p.Y < h - 1 && temp[p.X + (p.Y + 1) * Stride] == PickColor)
                {
                    temp[p.X + (p.Y + 1) * Stride] = FillValue;
                    fillPoints.Push(new Point(p.X, p.Y + 1));
                    mask[p.X, p.Y + 1] = 1;
                }
            }
            fillPoints.Clear();
            grayValues = (byte[])temp.Clone();
            System.Runtime.InteropServices.Marshal.Copy(grayValues, 0, (IntPtr)ptr, bytes);
        }

    }



}
