﻿using System;
namespace test.BinaryThreshold
{
    /*
     * Yan F, Zhang H, Kube C R. A multistage adaptive thresholding method[J]. 
     * Pattern recognition letters, 2005, 26(8): 1183-1191.   
     */
    public class MutliStageAdaptiveThresholdingYang
    {
        public MutliStageAdaptiveThresholdingYang()
        {

        }

    }
}
