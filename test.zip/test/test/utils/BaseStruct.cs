﻿using System;
using test.utils;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace test.utils
{
    public class BaseStruct
    {
        public int offset;
        public byte PixelValue;

        public BaseStruct()
        {
        }

        /// <summary>
        /// 引用动态库，使用C语言构建的动态库进行计算。
        /// </summary>
        /// <returns>The sum.</returns>
        /// <param name="a">The alpha component.</param>
        /// <param name="b">The blue component.</param>
        [DllImport("dll_fun.dll", EntryPoint = "sum")]
        public static extern int Sum(int a, int b);


        /// <summary>
        /// Gets the array from 3 channels image.
        /// </summary>
        /// <returns>The array from3 channels image.</returns>
        /// <param name="SourceImg">Source image.</param>
        public unsafe byte[,] GetArrayFrom3ChannelsImg(Bitmap SourceImg)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* Spointer = (byte*)SPtr.ToPointer();

            int Width = SourceImg.Width;
            int Height = SourceImg.Height;
            int SStride = SBdata.Stride;

            byte[,] Mask = new byte[Height, Width];
            int Offset = 0;
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Offset = i * SStride + j * 3;
                    Mask[i, j] = Spointer[offset];
                }
            }
            SourceImg.UnlockBits(SBdata);
            return Mask;
        }

        /// <summary>
        /// Gets the array from 1 channels image.
        /// </summary>
        /// <returns>The array from1 channels image.</returns>
        /// <param name="SourceImg">Source image.</param>
        public unsafe byte[,] GetArrayFrom1ChannelsImg(Bitmap SourceImg)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* Spointer = (byte*)SPtr.ToPointer();

            int Width = SourceImg.Width;
            int Height = SourceImg.Height;
            int SStride = SBdata.Stride;

            byte[,] Mask = new byte[Height, Width];
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Mask[i, j] = 0;
                }
            }

            int Offset = 0;
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Offset = i * SStride + j;
                    Mask[i, j] = Spointer[offset];
                }
            }

            SourceImg.UnlockBits(SBdata);
            return Mask;
        }


        /// <summary>
        /// Gets the mask of image.
        /// input image is 3 channels images.
        /// 经过验证，此算法可以有效的对图片进行操作。不会出现图片花斑、乱码等现象。
        /// 时间复杂度: 39ms --> intel i7-3770s, DDR3;
        /// </summary>
        /// <returns>The mask which only has 0 and 1.</returns>
        /// <param name="SourceImage">Source image.</param>
        public static Bitmap GetMask3Channel(Bitmap SourceImage)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            CreateGrayBitmap createGrayBitmap = new CreateGrayBitmap();
            Bitmap Mask = createGrayBitmap.GetGrayBitmap(SourceImage.Width, SourceImage.Height); // 生成单通道的灰度图。

            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImage, out BitmapData SBdata);
            IntPtr MPtr = getIntPtr.GetImgIntPtr(Mask, out BitmapData MBdata);

            int SWidth = SourceImage.Width;
            int SHeight = SourceImage.Height;
            int MWidth = Mask.Width;
            int MHeight = Mask.Height;

            int SStride = SBdata.Stride;
            int MStride = MBdata.Stride;

            int SarraySize = SHeight * SStride;
            int MarraySize = MHeight * MStride;

            byte[] SourceArraydata = new byte[SarraySize];
            byte[] MaskArraydata = new byte[MarraySize];

            Marshal.Copy(SBdata.Scan0, SourceArraydata, 0, SarraySize);
            Marshal.Copy(MBdata.Scan0, MaskArraydata, 0, MarraySize);

            int degreeOfParallelism = Environment.ProcessorCount - 1;
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                {
                    for (int j = 0; j < SWidth; j++)
                    {
                        int SOffset = i * SStride + j * 3;
                        int MOffset = i * MStride + j;

                        if (SourceArraydata[SOffset]==255)
                        {
                            MaskArraydata[MOffset] = 1;
                        }
                        else
                        {
                            MaskArraydata[MOffset] = 0;
                        }
                    }
                }
            });
            Marshal.Copy(MaskArraydata, 0, MBdata.Scan0, MaskArraydata.Length);
            SourceImage.UnlockBits(SBdata);
            Mask.UnlockBits(MBdata);

            return Mask;
        }

        /// <summary>
        /// Gets the mask of image.
        /// input image is 3 channels images. 
        /// 经过验证，此算法可以有效的对图片进行操作。不会出现图片花斑、乱码等现象。\
        /// 时间复杂度: 62ms --> intel i7-3770s, DDR3;
        /// </summary>
        /// <returns>The mask which only has 0 and 1.</returns>
        /// <param name="SourceImage">Source image.</param>
        public static Bitmap GetMask3ChannelDivid(Bitmap SourceImage)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            CreateGrayBitmap createGrayBitmap = new CreateGrayBitmap();
            ConvertSingleChannel convertSingleChannel = new ConvertSingleChannel();

            Bitmap SingleChannel = convertSingleChannel.Convert3ToSingleChannel(SourceImage);
            Bitmap Mask = SingleChannel.Clone(new Rectangle(0,0,SingleChannel.Width, SingleChannel.Height), PixelFormat.Format8bppIndexed); ; // 生成单通道的灰度图。

            IntPtr MPtr = getIntPtr.GetImgIntPtr(Mask, out BitmapData MBdata);


            int MWidth = Mask.Width;
            int MHeight = Mask.Height;
            int MStride = MBdata.Stride;
            int MarraySize = MHeight * MStride;

            byte[] MaskArraydata = new byte[MarraySize];

            Marshal.Copy(MBdata.Scan0, MaskArraydata, 0, MarraySize);

            int degreeOfParallelism = Environment.ProcessorCount - 1;
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, MHeight, options, i =>
            {
                {
                    for (int j = 0; j < MWidth; j++)
                    {

                        int MOffset = i * MStride + j;
                        MaskArraydata[MOffset] /= 1;
                        // MaskArraydata[MOffset] = SourceArraydata[SOffset];
                    }
                }
            });
            Marshal.Copy(MaskArraydata, 0, MBdata.Scan0, MaskArraydata.Length);
            Mask.UnlockBits(MBdata);

            return Mask;
        }



        /// <summary>
        /// Gets the mask of image.
        /// input image is 3 channels images.
        /// 经过验证，此算法可以有效的对图片进行操作。不会出现图片花斑、乱码等现象。
        /// </summary>
        /// <returns>The mask which only has 0 and 1.</returns>
        /// <param name="SourceImage">Source image.</param>
        public static Bitmap GetMask1Channel(Bitmap SourceImage)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            CreateGrayBitmap createGrayBitmap = new CreateGrayBitmap();
            Bitmap Mask = createGrayBitmap.GetGrayBitmap(SourceImage.Width, SourceImage.Height); // 生成单通道的灰度图。

            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImage, out BitmapData SBdata);
            IntPtr MPtr = getIntPtr.GetImgIntPtr(Mask, out BitmapData MBdata);

            int SWidth = SourceImage.Width;
            int SHeight = SourceImage.Height;
            int MWidth = Mask.Width;
            int MHeight = Mask.Height;

            int SStride = SBdata.Stride;
            int MStride = MBdata.Stride;

            int SarraySize = SHeight * SStride;
            int MarraySize = MHeight * MStride;

            byte[] SourceArraydata = new byte[SarraySize];
            byte[] MaskArraydata = new byte[MarraySize];

            Marshal.Copy(SBdata.Scan0, SourceArraydata, 0, SarraySize);
            Marshal.Copy(MBdata.Scan0, MaskArraydata, 0, MarraySize);

            int degreeOfParallelism = Environment.ProcessorCount - 1;
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                {
                    for (int j = 0; j < SWidth; j++)
                    {
                        int SOffset = i * SStride + j; // 这个一定要定义在并行for循环内部。
                        int MOffset = i * MStride + j; // 这个一定要定义在并行for循环内部。

                        if (SourceArraydata[SOffset] == 255)
                        {
                            MaskArraydata[MOffset] = 1;
                        }
                        else
                        {
                            MaskArraydata[MOffset] = 0;
                        }
                        // MaskArraydata[MOffset] = SourceArraydata[SOffset];
                    }
                }
            });
            Marshal.Copy(MaskArraydata, 0, MBdata.Scan0, MaskArraydata.Length);
            SourceImage.UnlockBits(SBdata);
            Mask.UnlockBits(MBdata);
            return Mask;
        }


        /// <summary>
        /// Gets the mask of image.
        /// input image is 3 channels images.
        /// 经过验证，此算法可以有效的对图片进行操作。不会出现图片花斑、乱码等现象。
        /// </summary>
        /// <returns>The mask which only has 0 and 1.</returns>
        /// <param name="SourceImage">Source image.</param>
        public static Bitmap ConvertMaskToBmap(Bitmap SourceImage)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            CreateGrayBitmap createGrayBitmap = new CreateGrayBitmap();
            Bitmap Mask = createGrayBitmap.GetGrayBitmap(SourceImage.Width, SourceImage.Height); // 生成单通道的灰度图。

            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImage);
            IntPtr MPtr = getIntPtr.GetImgIntPtr(Mask);

            BitmapData SBdata =getIntPtr.GetImgBmapData(SourceImage);
            BitmapData MBdata = getIntPtr.GetImgBmapData(Mask);

            int SWidth = SourceImage.Width;
            int SHeight = SourceImage.Height;
            int MWidth = Mask.Width;
            int MHeight = Mask.Height;

            int SStride = SBdata.Stride;
            int MStride = MBdata.Stride;

            int SarraySize = SHeight * SStride;
            int MarraySize = MHeight * MStride;

            byte[] SourceArraydata = new byte[SarraySize];
            byte[] MaskArraydata = new byte[MarraySize];

            Marshal.Copy(SBdata.Scan0, SourceArraydata, 0, SarraySize);
            Marshal.Copy(MBdata.Scan0, MaskArraydata, 0, MarraySize);

            int degreeOfParallelism = Environment.ProcessorCount - 1;
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                {
                    for (int j = 0; j < SWidth; j++)
                    {
                        int SOffset = i * SStride + j; // 这个一定要定义在并行for循环内部。
                        int MOffset = i * MStride + j; // 这个一定要定义在并行for循环内部。

                        MaskArraydata[MOffset] = (byte)(SourceArraydata[SOffset] * 255);
                        // MaskArraydata[MOffset] = SourceArraydata[SOffset];
                    }
                }
            });
            Marshal.Copy(MaskArraydata, 0, MBdata.Scan0, MaskArraydata.Length);
            SourceImage.UnlockBits(SBdata);
            Mask.UnlockBits(MBdata);
            return Mask;
        }


        /// <summary>
        /// Images to byte.
        /// 使用这个方法将bitmap转换成png格式的流数据，然后再传输给image组建
        /// 即可以正常现实。
        /// </summary>
        /// <returns>The to byte.</returns>
        /// <param name="SourceImg">Source image.</param>
        public static byte[] ImageToByte(Bitmap SourceImg)
        {
            using (var stream = new MemoryStream())
            {
                SourceImg.Save(stream, ImageFormat.Png);
                return stream.ToArray();
            }
        }

        /// <summary>
        /// Obsolete
        /// Assign Zero to empty image..
        /// 
        /// </summary>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="AssignZeroToImage">Threshold value.</param>
        public void AssignZeroToImage(Bitmap SourceBitmap)
        {

            GetIntPtr getIntPtr = new GetIntPtr();
            byte[] SourceArray = GetImageByteArray.GetImageArray(SourceBitmap);

            BitmapData SourceBdata = getIntPtr.GetImgBmapData(SourceBitmap);


            int SWidth = SourceBitmap.Width;
            int SHeight = SourceBitmap.Height;
            int SStride = SourceBdata.Stride;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                for (int j = 0; j < SWidth; j++)
                {
                    int offset = i * SStride + j;
                    SourceArray[offset] = 0;
                }
            }
            );

            Marshal.Copy(SourceArray, 0, SourceBdata.Scan0, SourceArray.Length);

            SourceBitmap.UnlockBits(SourceBdata);
        }



        public static bool[][] Image2Bool(Image img)
        {
            Bitmap bmp = new Bitmap(img);
            bool[][] s = new bool[bmp.Height][];
            for (int y = 0; y < bmp.Height; y++)
            {
                s[y] = new bool[bmp.Width];
                for (int x = 0; x < bmp.Width; x++)
                    s[y][x] = bmp.GetPixel(x, y).GetBrightness() < 0.3;
            }
            return s;

        }



        public static Bitmap Bool2Image(bool[][] s)
        {
            Bitmap bmp = new Bitmap(s[0].Length, s.Length);
            using (Graphics g = Graphics.FromImage(bmp)) g.Clear(Color.White);
            for (int y = 0; y < bmp.Height; y++)
                for (int x = 0; x < bmp.Width; x++)
                    if (s[y][x]) bmp.SetPixel(x, y, Color.Black);

            return (Bitmap)bmp;
        }

        public unsafe static Bitmap GenerateWhiteImg(int Width, int Height)
        {
            Bitmap bitmap = CreateGrayBitmap.StaticGetGrayBitmap(Width, Height);
            GetIntPtr getImgIntPtr = new GetIntPtr();
            IntPtr intPtr = getImgIntPtr.GetImgIntPtr(bitmap, out BitmapData bitmapData);
            byte* Pointer = (byte*)intPtr.ToPointer();
            int stride = bitmapData.Stride;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };
            Parallel.For(0, Height, options, i =>
            {
                for (int j = 0; j < Width; j++)
                {
                    Pointer[i * stride + j] = 255;
                }
            }
            );
            bitmap.UnlockBits(bitmapData); //释放资源
            return bitmap;
        }
    }
}
