﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace test.utils
{
    public class ConvertSingleChannel
    {
        CreateGrayBitmap CreateGray = new CreateGrayBitmap();
        GetIntPtr getIntPtr = new GetIntPtr();
        public ConvertSingleChannel()
        {
        }

        /// <summary>
        /// Converts 3 channels image to single channel image.
        /// </summary>
        /// <returns>The to single channel.</returns>
        /// <param name="SourceImg">Source image.</param>
        public unsafe Bitmap Convert3ToSingleChannel(Bitmap SourceImg)
        {
            if (SourceImg.PixelFormat != PixelFormat.Format24bppRgb)
            {
                return null;
            }
            // 这里时三通道的图片数据。
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* Spointer = (byte*)SPtr.ToPointer();
            int SHeight = SourceImg.Height;
            int SWidth = SourceImg.Width;
            int SStride = SBdata.Stride;

            // 这里是单通道的图片数据。
            Bitmap SingleChannelImg = CreateGray.GetGrayBitmap(SWidth, SHeight);// 产生一个灰度底图。
            IntPtr SinglePtr = getIntPtr.GetImgIntPtr(SingleChannelImg, out BitmapData SingleBdata);
            byte* SinglePointer = (byte*)SinglePtr.ToPointer();
            int SingleStride = SingleBdata.Stride;

            if (SourceImg.PixelFormat != PixelFormat.Format24bppRgb)
            {
                return null;
            }

            for (int i = 0; i < SHeight; i++)
            {
                for (int j = 0; j < SWidth; j++)
                {
                    byte temp = (byte)(0.114 * Spointer[i * SStride + j*3+0] + 0.587 * Spointer[i * SStride + j*3+1] + 0.299 * Spointer[i * SStride + j*3+2]);
                    SinglePointer[i * SingleStride + j] = temp;
                }
            }
            SourceImg.UnlockBits(SBdata);
            SingleChannelImg.UnlockBits(SingleBdata);
            return SingleChannelImg;
        }

        /// <summary>
        /// Converts 3 channels image to single channel image.
        /// </summary>
        /// <returns>The to single channel.</returns>
        /// <param name="SourceImg">Source image.</param>
        public unsafe Bitmap Convert1To3Channel(Bitmap SourceImg)
        {
            if (SourceImg.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                return null;
            }
            // 这里时三通道的图片数据。
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* Spointer = (byte*)SPtr.ToPointer();
            int SHeight = SourceImg.Height;
            int SWidth = SourceImg.Width;
            int SStride = SBdata.Stride;

            // 这里是单通道的图片数据。
            Bitmap SingleChannelImg = new Bitmap(SourceImg.Width, SourceImg.Height, PixelFormat.Format24bppRgb);
            IntPtr SinglePtr = getIntPtr.GetImgIntPtr(SingleChannelImg, out BitmapData SingleBdata);
            byte* SinglePointer = (byte*)SinglePtr.ToPointer();
            int SingleStride = SingleBdata.Stride;

            for (int i = 0; i < SHeight; i++)
            {
                for (int j = 0; j < SWidth; j++)
                {
                    byte temp = Spointer[i * SStride + j];
                    int SingleOffset = i * SingleStride + j*3;
                    SinglePointer[SingleOffset] = SinglePointer[SingleOffset + 1]
                     = SinglePointer[SingleOffset + 2] = temp;
                }
            }
            SourceImg.UnlockBits(SBdata);
            SingleChannelImg.UnlockBits(SingleBdata);
            return SingleChannelImg;
        }

        /// <summary>
        /// Converts 3 channels image to single channel image.
        /// </summary>
        /// <returns>The to single channel.</returns>
        /// <param name="SourceImg">Source image.</param>
        public unsafe Bitmap Convert4ToSingleChannel(Bitmap SourceImg)
        {
            List<PixelFormat> list = new List<PixelFormat>();
            list.Add(PixelFormat.Format32bppArgb);
            list.Add(PixelFormat.Format32bppPArgb);
            list.Add(PixelFormat.Format32bppRgb);
            byte Flag = 0;
            foreach (var item in list)
            {
                if (SourceImg.PixelFormat == item)
                {
                    Flag=1;
                    break;
                }
            }

            if (Flag==0)
            {
                return null;
            }

            // 这里时三通道的图片数据。
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* Spointer = (byte*)SPtr.ToPointer();
            int SHeight = SourceImg.Height;
            int SWidth = SourceImg.Width;
            int SStride = SBdata.Stride;

            // 这里是单通道的图片数据。
            Bitmap SingleChannelImg = CreateGray.GetGrayBitmap(SWidth, SHeight);
            IntPtr SinglePtr = getIntPtr.GetImgIntPtr(SingleChannelImg, out BitmapData SingleBdata);
            byte* SinglePointer = (byte*)SinglePtr.ToPointer();
            int SingleStride = SingleBdata.Stride;

            for (int i = 0; i < SHeight; i++)
            {
                for (int j = 0; j < SWidth; j++)
                {

                    SinglePointer[i * SingleStride + j] = (byte)(0.114 * Spointer[i * SStride + j * 4 + 1] + 0.587 * Spointer[i * SStride + j * 4 + 2] + 0.299 * Spointer[i * SStride + j * 4 + 3]); ;
                }
            }
            SourceImg.UnlockBits(SBdata);
            SingleChannelImg.UnlockBits(SingleBdata);
            return SingleChannelImg;
        }
    }
}
