﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace test.utils
{
    public class Tools
    {
        string log_path = "/home/samzhang/图片/log.txt";
        public Tools()
        {

        }

        /// <summary>
        /// Writes the by line.
        /// </summary>
        /// <param name="path">Path.</param>
        /// <param name="DataLine">Data line.</param>
        public static void WriteByLine(string path, string DataLine)
        {
            FileStream fs = new FileStream(path, FileMode.Append);//创建文件流
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(DataLine);
            sw.Close();//关闭写入器
            fs.Close();//关闭文件流
        }

        public static void WriteArray(string path, byte[,] ImgArray)
        {
            FileStream fs1;

            //判断是否已经有了这个文件
            if (!File.Exists(path))
            {
                //没有则创建这个文件
                fs1 = new FileStream(path, FileMode.Create);//创建写入文件   
            }

            using (StreamWriter sw = File.AppendText(path))
            {
                string StrRecord = string.Empty;
                for (int i = 0; i < ImgArray.GetLength(0); i++)
                {
                    for (int j = 0; j < ImgArray.GetLength(1); j++)
                    {
                        StrRecord += ImgArray[i, j].ToString() + ",";
                    }
                    sw.WriteLine(StrRecord);
                    StrRecord = string.Empty;
                }
            }
        }


        /// <summary>
        /// Converts the image to byte array.
        /// </summary>
        /// <returns>The image to byte array.</returns>
        /// <param name="bitmap">Bitmap.</param>
        public byte[] ConvertImageToByteArray(Bitmap bitmap)
        {
            BitmapData bitmapData;
            BicuBic bicuBic = new BicuBic();
            IntPtr intPtr = bicuBic.GetIntPtr(bitmap, out bitmapData);
            int bytes = bitmapData.Height * bitmapData.Width * 3;
            byte[] rgbValues = new byte[bytes];

            System.Runtime.InteropServices.Marshal.Copy(intPtr, rgbValues, 0, bytes);
            return rgbValues;
        }


        public IntPtr GetIntPtr(Bitmap bitmap, out BitmapData bitmapData)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            bitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            IntPtr NewintPtr = bitmapData.Scan0;
            return NewintPtr;
        }


        public IntPtr GetIntPtr(Bitmap bitmap, out BitmapData bitmapData, ImageLockMode imageLockMode)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            bitmapData = bitmap.LockBits(Newrectangle, imageLockMode, bitmap.PixelFormat);
            IntPtr NewintPtr = bitmapData.Scan0;
            return NewintPtr;
        }


        public void Threshold(Bitmap SourceBitmap)
        {
            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            int Offset = 0;
            unsafe
            {
                byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                for (int i = 0; i < SourceBdata.Height; i++)
                {
                    for (int j = 0; j < SourceBdata.Width; j++)
                    {
                        Offset = i * SourceBdata.Stride + j * 3;
                        if (SourcePointer[Offset]!=255)
                        {
                            SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 0;
                        }
                    }
                }
            }
            SourceBitmap.UnlockBits(SourceBdata);
        }


        public void Threshold(Bitmap SourceBitmap, int ThresholdValue)
        {
            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            int Offset = 0;
            unsafe
            {
                byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                for (int i = 0; i < SourceBdata.Height; i++)
                {
                    for (int j = 0; j < SourceBdata.Width; j++)
                    {
                        Offset = i * SourceBdata.Stride + j * 3;
                        if (SourcePointer[Offset] <= ThresholdValue)
                        {
                            SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 0;
                        }
                        else
                        {
                            SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 255;
                        }
                    }
                }
            }
            SourceBitmap.UnlockBits(SourceBdata);
        }


        /// <summary>
        /// Threshold1s the channle.
        /// </summary>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="ThresholdValue">Threshold value.</param>
        public void Threshold1Channle(Bitmap SourceBitmap, int ThresholdValue)
        {
            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            int Offset = 0;
            unsafe
            {
                byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                for (int i = 0; i < SourceBitmap.Height; i++)
                {
                    for (int j = 0; j < SourceBitmap.Width; j++)
                    {
                        Offset = i * SourceBdata.Stride + j;
                        if (SourcePointer[Offset] <= ThresholdValue)
                        {
                            SourcePointer[Offset] = 0;
                        }
                        else
                        {
                            SourcePointer[Offset] = 255;
                        }
                    }
                }
            }
            SourceBitmap.UnlockBits(SourceBdata);
        }

        /// <summary>
        /// Threshold1s the channle mp. Multi-thread.
        /// </summary>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="ThresholdValue">Threshold value.</param>
        public Bitmap Threshold1ChannleIV(Bitmap SourceBitmap, int ThresholdValue)
        {
            if (SourceBitmap.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                ConvertSingleChannel convertSingleChannel = new ConvertSingleChannel();
                SourceBitmap = convertSingleChannel.Convert3ToSingleChannel(SourceBitmap);
            }

            GetIntPtr getIntPtr = new GetIntPtr();
            byte[] SourceArray = GetImageByteArray.GetImageArray(SourceBitmap);

            BitmapData SourceBdata = getIntPtr.GetImgBmapData(SourceBitmap);


            int SWidth = SourceBitmap.Width;
            int SHeight = SourceBitmap.Height;
            int SStride = SourceBdata.Stride;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                for (int j = 0; j < SWidth; j++)
                {
                    int offset = i * SStride + j;

                    if (SourceArray[offset] >= ThresholdValue)
                    {
                        SourceArray[offset] = 255;
                    }
                    else if (SourceArray[offset] < ThresholdValue)
                    {
                        SourceArray[offset] = 0;
                    }

                }
            }
            );

            Marshal.Copy(SourceArray, 0, SourceBdata.Scan0, SourceArray.Length);

            SourceBitmap.UnlockBits(SourceBdata);
            return SourceBitmap;
        }


        /// <summary>
        /// Threshold1s the channle mp. Multi-thread.
        /// </summary>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="ThresholdValue">Threshold value.</param>
        public Bitmap Threshold1ChannleMP(Bitmap SourceBitmap, int ThresholdValue)
        {
            if (SourceBitmap.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                ConvertSingleChannel convertSingleChannel = new ConvertSingleChannel();
                SourceBitmap = convertSingleChannel.Convert3ToSingleChannel(SourceBitmap);
            }

            GetIntPtr getIntPtr = new GetIntPtr();
            byte[] SourceArray = GetImageByteArray.GetImageArray(SourceBitmap);

            BitmapData SourceBdata = getIntPtr.GetImgBmapData(SourceBitmap);


            int SWidth = SourceBitmap.Width;
            int SHeight = SourceBitmap.Height;
            int SStride = SourceBdata.Stride;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, SHeight, options, i =>
            {
                for (int j = 0; j < SWidth; j++)
                {
                    int offset = i * SStride + j;

                    if (SourceArray[offset] >= ThresholdValue)
                    {
                        SourceArray[offset] = 0;
                    }
                    else if (SourceArray[offset] < ThresholdValue)
                    {
                        SourceArray[offset] = 255;
                    }

                }
            }
            );

            Marshal.Copy(SourceArray, 0, SourceBdata.Scan0, SourceArray.Length);

            SourceBitmap.UnlockBits(SourceBdata);
            return SourceBitmap;
        }


        /// <summary>
        /// Threshold the specified SourceBitmap, ThresholdValue and reverse. 
        /// if reverse is true, set pixel>threshold to 0; 
        /// and piexl less than threshold, set pixel to be 255;
        /// </summary>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="ThresholdValue">Threshold value.</param>
        /// <param name="reverse">If set to <c>true</c> reverse.</param>
        public void Threshold(Bitmap SourceBitmap, int ThresholdValue, bool reverse)
        {
            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            int Offset = 0;
            unsafe
            {
                byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                if (reverse)
                {
                    for (int i = 0; i < SourceBdata.Height; i++)
                    {
                        for (int j = 0; j < SourceBdata.Width; j++)
                        {
                            Offset = i * SourceBdata.Stride + j * 3;
                            if (SourcePointer[Offset] <= ThresholdValue)
                            {
                                SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 255;
                            }
                            else
                            {
                                SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 0;
                            }
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < SourceBdata.Height; i++)
                    {
                        for (int j = 0; j < SourceBdata.Width; j++)
                        {
                            Offset = i * SourceBdata.Stride + j * 3;
                            if (SourcePointer[Offset] <= ThresholdValue)
                            {
                                SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 0;
                            }
                            else
                            {
                                SourcePointer[Offset] = SourcePointer[Offset + 1] = SourcePointer[Offset + 2] = 255;
                            }
                        }
                    }
                }

            }
            SourceBitmap.UnlockBits(SourceBdata);
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public List<Point> FindCrisscross(Bitmap SourceBitmap, int SizeWindows)
        {
            List<Point> RecordCrisscross = new List<Point>();
            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            bool IsCrissCross = false;
            double HalfWindow = Math.Floor((SizeWindows / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            Point CrissCrosspoint = new Point();


            unsafe void GetPixelValueToMatrix(byte* SourceIntPtr, int SourceOffset, BitmapData SourceBitmapData, int WSize, ref bool IsCrisscross)
            {
                int Judgment = Convert.ToInt32(WSize * WSize * 0.38);
                int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3;
                byte[,] GetPixelValue = new byte[WSize, WSize];

                unsafe
                {
                    int PixelCount = 0;
                    int PixelOffset = 0;

                    for (int i = 0; i < WSize; i++)
                    {
                        for (int j = 0; j < WSize; j++)
                        {
                            PixelOffset = ReLocalOffset + i * SourceBitmapData.Stride + j * 3;
                            GetPixelValue[i, j] = SourceIntPtr[PixelOffset];
                            if (SourceIntPtr[PixelOffset] == 255)
                            {
                                PixelCount++;
                            }
                        }
                    }

                    if (PixelCount >= Judgment)
                    {
                        SourceIntPtr[SourceOffset] = SourceIntPtr[SourceOffset + 1] = 0;
                        SourceIntPtr[SourceOffset + 2] = 255;

                        SourceIntPtr[SourceOffset - 3] = SourceIntPtr[SourceOffset - 2] = 0;
                        SourceIntPtr[SourceOffset - 1] = 255;

                        SourceIntPtr[SourceOffset + 3] = SourceIntPtr[SourceOffset + 4] = 0;
                        SourceIntPtr[SourceOffset + 5] = 255;
                        IsCrisscross = true;
                    }
                }
            }

            unsafe
            {
                try
                {
                    byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                    int Offset = 0;
                    for (int i = WindowsStrid; i < SourceBdata.Height- WindowsStrid; i++)
                    {
                        for (int j = WindowsStrid; j < SourceBdata.Width- WindowsStrid; j++)
                        {
                            Offset = i * SourceBdata.Stride + j * 3;
                            GetPixelValueToMatrix(SourcePointer, Offset, SourceBdata, SizeWindows, ref IsCrissCross);
                            if (IsCrissCross)
                            {
                                CrissCrosspoint.X = j;
                                CrissCrosspoint.Y = i;
                                RecordCrisscross.Add(CrissCrosspoint);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    WriteByLine(log_path, "FindCrisscross Pointer:" + ex.Message);
                }

            }
            SourceBitmap.UnlockBits(SourceBdata);
            return RecordCrisscross;
        }


        /// <summary>
        /// Dilate the specified SrcImage and Swindow.
        /// Paralleling. Using rhombus Neighborhood.
        /// </summary>
        /// <returns>The dilate.</returns>
        /// <param name="SrcImage">Source image.</param>
        /// <param name="Swindow">Swindow.</param>
        public Bitmap Dilate(Bitmap SrcImage, int Swindow)
        {
            Bitmap CopyImage = SrcImage.Clone(new Rectangle(0,0, SrcImage.Width, SrcImage.Height), SrcImage.PixelFormat);
            double HalfWindow = Math.Floor((Swindow / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            IntPtr SourcePtr = GetIntPtr(SrcImage, out BitmapData SourceBdata);

            IntPtr CopyPtr = GetIntPtr(CopyImage, out BitmapData CopyBdata);

            int SrcHeight = SourceBdata.Height;
            int SrcWidth = SourceBdata.Width;
            bool Flag = false;
            unsafe
            {
                try
                {
                    byte* SrcPtr = (byte*)SourcePtr.ToPointer();
                    byte* CPtr = (byte*)CopyPtr.ToPointer();
                    int SrcOffset, CopyOffset;
                    for (int i = WindowsStrid; i < SrcHeight-WindowsStrid; i++)
                    {
                        for (int j = WindowsStrid; j < SrcWidth-WindowsStrid; j++)
                        {

                                SrcOffset = i * SourceBdata.Stride + j * 3;
                                CopyOffset = i * CopyBdata.Stride + j * 3;
                                Flag = DilateNeighborhood(SrcPtr, CPtr, SrcOffset, CopyOffset, SourceBdata, CopyBdata, Swindow);

                        }
                    }
                }
                catch (Exception ex)
                {
                    WriteByLine(log_path, "Dilating error:" + ex.Message);
                }
            }
            SrcImage.UnlockBits(SourceBdata);
            CopyImage.UnlockBits(CopyBdata);
            return CopyImage;
        }


        /// <summary>
        /// Gets the Neighborhood pixel value to matrix. 5×5 size pixels values.
        /// </summary>
        /// <returns> Return byte[,],The pixel value to matrix.</returns>
        /// <param name="SourceIntPtr">Source byte*(pointer).</param>
        /// <param name="SourceOffset">Source offset.</param>
        /// <param name="SourceBitmapData">Source bitmap data.</param>
        public unsafe byte[,] Neighborhood(byte* SourceIntPtr, int SourceOffset, BitmapData SourceBitmapData, int WSize)
        {
            double HalfWindow = Math.Floor((WSize / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3;

            byte[,] GetPixelValue = new byte[5, 5];


            unsafe
            {
                try
                {
                    int PixelOffset = 0;
                    for (int i = 0; i < WSize; i++)
                    {
                        for (int j = 0; j < WSize; j++)
                        {
                            PixelOffset = ReLocalOffset + i * SourceBitmapData.Stride + j * 3;
                            GetPixelValue[i, j] = SourceIntPtr[PixelOffset];
                        }
                    }
                }

                catch (Exception ex)
                {
                    WriteByLine(log_path, "GetPixelValueToMatrix:" + ex.Message);
                }
            }
            return GetPixelValue;
        }


        /// <summary>
        /// Gets the Neighborhood pixel value to matrix. WSize×WSize size pixels values.
        /// No Paralleling.
        /// </summary>
        /// <returns> Return byte[,],The pixel value to matrix.</returns>
        /// <param name="SourceIntPtr">Source byte*(pointer).</param>
        /// <param name="SourceOffset">Source offset.</param>
        /// <param name="SourceBitmapData">Source bitmap data.</param>
        public unsafe bool DilateNeighborhood(byte* SourceIntPtr, byte* CopyIntPtr, int SourceOffset, int CopyOffset, BitmapData SourceBitmapData, BitmapData CopyBdata, int WSize)
        {
            bool Flag = false;
            double HalfWindow = Math.Floor((WSize / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);

            int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3; // 读取位置重新定位
            int CopyRLocalOffset = CopyOffset - WindowsStrid * CopyBdata.Stride - WindowsStrid * 3;

            byte[,] GetPixelValue = new byte[WSize, WSize];
            byte[,] DilateTemplate = new byte[WSize, WSize];
            Array.Clear(DilateTemplate, 0, WSize* WSize);

            int OffsetX, OffsetY;
            for (int i = 0; i < WSize; i++)
            {
                for (int j = 0; j < WSize; j++)
                {
                    OffsetX = Math.Abs(i - WindowsStrid);
                    OffsetY = Math.Abs(j - WindowsStrid);
                    if (OffsetY+OffsetX<=WindowsStrid)
                    {
                        DilateTemplate[i, j] = 1;
                    }
                }
            }

            unsafe
            {
                int PixelOffset = 0;
                int CPixeloffset = 0;

                for (int i = 0; i < WSize; i++)
                {
                    for (int j = 0; j < WSize; j++)
                    {
                        PixelOffset = ReLocalOffset + i * SourceBitmapData.Stride + j * 3;
                        if (SourceIntPtr[PixelOffset] > 0)
                        {
                            Flag = true;
                            break;
                        }
                    }
                }

                if (Flag) //这里是对克隆图像进行重赋值。
                {
                    for (int i = 0; i < WSize; i++)
                    {
                        for (int j = 0; j < WSize; j++)
                        {
                            CPixeloffset = CopyRLocalOffset + i * CopyBdata.Stride + j * 3;
                            CopyIntPtr[CPixeloffset] = CopyIntPtr[CPixeloffset + 1] = CopyIntPtr[CPixeloffset + 2] = 255;
                        }
                    }
                }

            }
            return Flag;
        }


        /// <summary>
        /// 
        /// Assigning 255 to the Neighborhood pixel value to matrix. 5×5 size pixels values.
        /// No Paralleling.
        /// </summary>
        /// <returns> Return byte[,],The pixel value to matrix.</returns>
        /// <param name="SourceIntPtr">Source byte*(pointer).</param>
        /// <param name="SourceOffset">Source offset.</param>
        /// <param name="SourceBitmapData">Source bitmap data.</param>
        public unsafe void AssignNumberToNeighborhood(byte* SourceIntPtr, int SourceOffset, BitmapData SourceBitmapData, int WSize)
        {
            double HalfWindow = Math.Floor((WSize / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3;

            unsafe
            {
                try
                {
                    int PixelOffset = 0;
                    for (int i = 0; i < WSize; i++)
                    {
                        for (int j = 0; j < WSize; j++)
                        {
                            PixelOffset = ReLocalOffset + i * SourceBitmapData.Stride + j * 3;
                            if (SourceIntPtr[PixelOffset]!=255)
                            {
                                SourceIntPtr[PixelOffset] = SourceIntPtr[PixelOffset + 1] = SourceIntPtr[PixelOffset + 2] = 255;
                            }
                        }
                    }
                }

                catch (Exception ex)
                {
                    WriteByLine(log_path, "GetPixelValueToMatrix:" + ex.Message);
                }
            }
        }


        /// <summary>
        /// 腐蚀算法无效果。
        /// Erosion the specified SourceBitmap and Swindow.
        /// </summary>
        /// <returns>The erosion.</returns>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="Swindow">Swindow.</param>
        public unsafe Bitmap Erosion(Bitmap SourceBitmap, int Swindow)
        {
            Rectangle rectangle = new Rectangle(0,0, SourceBitmap.Width, SourceBitmap.Height);
            Bitmap DestBitmap = SourceBitmap.Clone(rectangle, SourceBitmap.PixelFormat);
            double HalfWindow = Math.Floor(Swindow / 2D);
            int WindowsStrid = Convert.ToInt32(HalfWindow);

            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            IntPtr DestPtr = GetIntPtr(DestBitmap, out BitmapData DestBdata);

            int DestHeight = DestBdata.Height;
            int DestWidth = DestBdata.Width;
            int DestStride = DestBdata.Stride;

            int BHeight = SourceBdata.Height;
            int Bwidth = SourceBdata.Width;
            int BStride = SourceBdata.Stride;

            try
            {
                byte* SourceImgPointer = (byte*)SourcePtr.ToPointer();
                byte* DestImgPointer = (byte*)DestPtr.ToPointer();
                int BOffset, DestOffset;

                for (int i = WindowsStrid; i < BHeight - WindowsStrid; i++)
                {
                    for (int j = WindowsStrid; j < Bwidth - WindowsStrid; j++)
                    {
                        BOffset = i * BStride + j * 3;
                        DestOffset = i * DestStride + j * 3;
                        DoErosionOperator(SourceImgPointer, DestImgPointer, BOffset, DestOffset, SourceBdata, DestBdata, Swindow, i, j);
                    }
                }
            }
            catch (Exception ex)
            {
                WriteByLine(log_path, "Erosion:" + ex.Message);
            }
            SourceBitmap.UnlockBits(SourceBdata);
            DestBitmap.UnlockBits(DestBdata);
            return DestBitmap;
        }


        private unsafe void DoErosionOperator(byte* SourceIntPtr, byte* DestIntPtr, int SourceOffset, int DestOffset, BitmapData SourceBitmapData, BitmapData DestBitmapData, int WSize, int Index_i, int Index_j)
        {
            double HalfWindow = Math.Floor((WSize / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            int CountDiamondValue = WSize * WSize * 255; // 计算菱形对应的像素值的总数。

            int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3; // 读取位置重新定位
            int CurrentOffset;

            int Bstride = SourceBitmapData.Stride;
            int Dstride = DestBitmapData.Stride;
            int Statistic = 0;
            for (int i = 0; i < WSize; i++)
            {
                for (int j = 0; j < WSize; j++)
                {
                    CurrentOffset = ReLocalOffset + (i * Bstride) + j * 3;
                    Statistic += SourceIntPtr[CurrentOffset];
                }
            }

            if (Statistic>0 && Statistic < CountDiamondValue)
            {
                DestOffset = Index_i * DestBitmapData.Stride + Index_j * 3;
                DestIntPtr[DestOffset] = DestIntPtr[DestOffset + 1] = DestIntPtr[DestOffset + 2] = 0;
            }
        }

        /// <summary>
        /// 腐蚀算法无效果。
        /// Erosion the specified SourceBitmap and Swindow.
        /// </summary>
        /// <returns>The erosion.</returns>
        /// <param name="SourceBitmap">Source bitmap.</param>
        /// <param name="Swindow">Swindow.</param>
        public unsafe Bitmap ErosionGrayScale(Bitmap SourceBitmap, int Swindow)
        {
            Rectangle rectangle = new Rectangle(0, 0, SourceBitmap.Width, SourceBitmap.Height);
            Bitmap DestBitmap = SourceBitmap.Clone(rectangle, SourceBitmap.PixelFormat);
            double HalfWindow = Math.Floor(Swindow / 2D);
            int WindowsStrid = Convert.ToInt32(HalfWindow);

            IntPtr SourcePtr = GetIntPtr(SourceBitmap, out BitmapData SourceBdata);
            IntPtr DestPtr = GetIntPtr(DestBitmap, out BitmapData DestBdata);

            int DestHeight = DestBdata.Height;
            int DestWidth = DestBdata.Width;
            int DestStride = DestBdata.Stride;

            int BHeight = SourceBdata.Height;
            int Bwidth = SourceBdata.Width;
            int BStride = SourceBdata.Stride;

            try
            {
                byte* SourceImgPointer = (byte*)SourcePtr.ToPointer();
                byte* DestImgPointer = (byte*)DestPtr.ToPointer();
                int BOffset, DestOffset;

                for (int i = WindowsStrid; i < BHeight - WindowsStrid; i++)
                {
                    for (int j = WindowsStrid; j < Bwidth - WindowsStrid; j++)
                    {
                        BOffset = i * BStride + j;
                        DestOffset = i * DestStride + j;
                        DoErosionOperator(SourceImgPointer, DestImgPointer, BOffset, DestOffset, SourceBdata, DestBdata, Swindow, i, j);
                    }
                }
            }
            catch (Exception ex)
            {
                WriteByLine(log_path, "Erosion:" + ex.Message);
            }
            SourceBitmap.UnlockBits(SourceBdata);
            DestBitmap.UnlockBits(DestBdata);
            return DestBitmap;
        }


        private unsafe void DoErosionOperatorGrayScale(byte* SourceIntPtr, byte* DestIntPtr, int SourceOffset, int DestOffset, BitmapData SourceBitmapData, BitmapData DestBitmapData, int WSize, int Index_i, int Index_j)
        {
            double HalfWindow = Math.Floor((WSize / 2D));
            int WindowsStrid = Convert.ToInt32(HalfWindow);
            int CountDiamondValue = WSize * WSize * 255; // 计算菱形对应的像素值的总数。

            int ReLocalOffset = SourceOffset - WindowsStrid * SourceBitmapData.Stride - WindowsStrid * 3; // 读取位置重新定位
            int CurrentOffset;

            int Bstride = SourceBitmapData.Stride;
            int Dstride = DestBitmapData.Stride;
            int Statistic = 0;
            for (int i = 0; i < WSize; i++)
            {
                for (int j = 0; j < WSize; j++)
                {
                    CurrentOffset = ReLocalOffset + (i * Bstride) + j;
                    Statistic += SourceIntPtr[CurrentOffset];
                }
            }

            if (Statistic > 0 && Statistic < CountDiamondValue)
            {
                DestOffset = Index_i * DestBitmapData.Stride + Index_j;
                DestIntPtr[DestOffset]= 0;
            }
        }



        /// <summary>
        /// Difference the specified Source and Erosion.
        /// </summary>
        /// <returns>The difference.</returns>
        /// <param name="Source">Source.</param>
        /// <param name="Erosion">Erosion.</param>
        public unsafe Bitmap Difference(Bitmap Source, Bitmap Erosion)
        {
            Bitmap SourceClone = Source.Clone(new Rectangle(0,0,Source.Width, Source.Height), Source.PixelFormat);
            IntPtr SourcePtr = GetIntPtr(SourceClone, out BitmapData SourceBData);
            IntPtr ErosionPtr = GetIntPtr(Erosion, out BitmapData ErosionBData);

            byte* SourcePointer = (byte*)SourcePtr.ToPointer();
            byte* ErosionPointer = (byte*)ErosionPtr.ToPointer();

            int SourceOffset = 0;
            int ErosionOffset = 0;
            for (int i = 0; i < Erosion.Height; i++)
            {
                for (int j = 0; j < Erosion.Width; j++)
                {
                    SourceOffset = i * SourceBData.Stride + j * 3;
                    ErosionOffset = i * ErosionBData.Stride + j * 3;

                    SourcePointer[SourceOffset] -= ErosionPointer[ErosionOffset];
                    SourcePointer[SourceOffset + 1] = SourcePointer[SourceOffset + 2] = SourcePointer[SourceOffset];
                }
            }
            SourceClone.UnlockBits(SourceBData);
            Erosion.UnlockBits(ErosionBData);
            return SourceClone;
        }

    }
}
