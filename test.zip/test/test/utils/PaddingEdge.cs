﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test.utils
{
    public class PaddingEdge
    {
        string log_path = "/home/samzhang/图片/log.txt";
        GetIntPtr GetPtr = new GetIntPtr();
        public PaddingEdge()
        {
        }

        /// <summary>
        /// 扩增图片，同时填充边缘为0。
        /// </summary>
        /// <returns>The edge.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// <param name="PaddingPixels">Padding pixels number.</param>
        /// <param name="PaddingValue">Padding pixels value.</param>
        public Bitmap PaddingImgEdge(Bitmap RawBitmap, int PaddingPixels, byte PaddingValue)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);
            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址

            int SidePadding = PaddingPixels * 2; //不一定能用的上

            Bitmap bitmap = new Bitmap(RawBitmap.Width + SidePadding, RawBitmap.Height + SidePadding, RawBitmap.PixelFormat);
            BitmapData NewbitmapData;
            IntPtr NewintPtr = GetPtr.GetImgIntPtr(bitmap, out NewbitmapData); //得到指针或者句柄，这是一个C#平台指定的类型。

            RawBitmap.UnlockBits(bitmapData);
            byte[,] SourceImageArray = ImageTo2DByteArray(RawBitmap);

            //先给新图片设置底色
            unsafe
            {
                int Innner_offset = 0;
                byte* ptr = (byte*)NewintPtr;
                var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                for (int i = 0; i < NewbitmapData.Height; i++)
                {
                    for (int j = 0; j < NewbitmapData.Width; j++)
                    {
                        Innner_offset = i * NewbitmapData.Stride + j * 3;
                        ptr[Innner_offset + 0] = ptr[Innner_offset + 1] = ptr[Innner_offset + 2] = PaddingValue;
                    }
                }
            }// padding图片的底色设置完成

            int InnerHeight = NewbitmapData.Height;
            int InnerWidth = NewbitmapData.Width;

            unsafe
            {
                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            if ((i >= PaddingPixels && i < NewbitmapData.Height - PaddingPixels) && (j >= PaddingPixels && j < NewbitmapData.Width - PaddingPixels))
                            {
                                //这样写不能在最后加offset。
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;
                                InnerValue = SourceImageArray[i - PaddingPixels, j - PaddingPixels];
                                DestPointer[Innner_offset + 0] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                        //string LogStr = i.ToString();
                        //Tools.WriteByLine(log_path, LogStr);
                        // Please note
                        // 如果使用 height*Stride + widthIndex* 3的方式就不能再加offset。
                        // DestPointer += offset; 
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Assign Array Pointer:" + ex.Message);
                }

                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补上部空缺
                            if (i < PaddingPixels)
                            {
                                int Diffience = PaddingPixels - i;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; // 当前空值
                                int Padding_offset = (PaddingPixels + Diffience - 1) * NewbitmapData.Stride + j * 3; //目标值

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补下部空缺
                            else if (i > InnerHeight - Convert.ToInt32(Math.Ceiling(1.4 * PaddingPixels)))
                            {
                                int Diffience = i + PaddingPixels - InnerHeight;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;//当前空值
                                int Padding_offset = (i - PaddingPixels - Diffience) * NewbitmapData.Stride + j * 3; // 提取的目标数据

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补左侧空缺
                            else if (j < PaddingPixels)
                            {
                                int Diffience = PaddingPixels - j;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (PaddingPixels + Diffience) * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补右侧空缺
                            else if (i >= 0 && i < InnerHeight && j > InnerWidth - Math.Ceiling(1.5 * PaddingPixels))
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = Innner_offset - PaddingPixels * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Padding Pointer:" + ex.Message);
                }

            }
            bitmap.UnlockBits(NewbitmapData);
            return bitmap;
        }


        /// <summary>
        /// 有问题，暂时无法修复
        /// 扩增图片，同时填充边缘为0
        /// </summary>
        /// <returns>The edge.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// <param name="PaddingPixels"> number of padding pixels.</param>
        public Bitmap PaddingImgEdge(Bitmap RawBitmap, int PaddingPixels)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);
            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址

            int SidePadding = PaddingPixels * 2; //不一定能用的上

            int RawWidth = RawBitmap.Width ;
            int RawHeight = RawBitmap.Height ;
            Bitmap bitmap = new Bitmap(RawWidth + SidePadding, RawHeight + SidePadding, RawBitmap.PixelFormat);
            IntPtr NewintPtr = GetPtr.GetImgIntPtr(bitmap, out BitmapData NewbitmapData); //得到指针或者句柄，这是一个C#平台指定的类型。

            int IWidth = bitmapData.Width;


            int InnerHeight = NewbitmapData.Height;
            int InnerWidth = NewbitmapData.Width;

            unsafe
            {
                try
                {
                    byte* RawPoint = (byte*)intPtr.ToPointer();
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();

                    for (int i = 0; i < RawHeight; i++)
                    {
                        for (int j = 0; j < RawWidth; j++)
                        {
                            int Innner_offset = (i + PaddingPixels) * NewbitmapData.Stride + (j + PaddingPixels) * 3;
                            int RawOffset = i * bitmapData.Stride + j * 3;
                            DestPointer[Innner_offset] = RawPoint[RawOffset];
                            DestPointer[Innner_offset + 1] = RawPoint[RawOffset + 1]; 
                            DestPointer[Innner_offset + 2] = RawPoint[RawOffset + 2];
                        }
                    }
                    RawBitmap.UnlockBits(bitmapData); //释放原始图片的资源占用。
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Assign Array Pointer:" + ex.Message);
                }
                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补上部空缺
                            if (i < PaddingPixels && j > 0 && j < InnerWidth - PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; // 当前空值
                                int Padding_offset = (-i + PaddingPixels * 2) * NewbitmapData.Stride + j * 3;

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                    }

                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补下部空缺
                            if (i > (InnerHeight - PaddingPixels))
                            {
                                int boundary = InnerHeight - PaddingPixels;
                                int Innner_offset = (i - 1) * NewbitmapData.Stride + j * 3;//当前空值坐标
                                int Padding_offset = (-i + 2 * boundary) * NewbitmapData.Stride + j * 3; // 提取的目标数据

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补左侧空缺
                            else if (i >= 0 && i < InnerHeight && j < PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (-j + 2 * PaddingPixels) * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补右侧空缺
                            else if (i >= 0 && i < InnerHeight && j > (InnerWidth - PaddingPixels))
                            {
                                int boundary = InnerWidth - PaddingPixels;
                                int Innner_offset = i * NewbitmapData.Stride + (j - 1) * 3; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (-j + 2 * boundary) * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Padding Pointer:" + ex.Message);
                }
            }

            bitmap.UnlockBits(NewbitmapData);
            return bitmap;
        }


        /// <summary>
        /// 有问题，暂时无法修复
        /// 扩增图片，同时填充边缘为0
        /// </summary>
        /// <returns>The edge.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// <param name="PaddingPixels"> number of padding pixels.</param>
        public Bitmap PaddingImgEdge1Channel(Bitmap RawBitmap, int PaddingPixels)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);
            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址

            int SidePadding = PaddingPixels * 2;
            int RawWidth = RawBitmap.Width;
            int RawHeight = RawBitmap.Height;

            CreateGrayBitmap CreateGray = new CreateGrayBitmap();
            Bitmap bitmap = CreateGray.GetGrayBitmap(RawWidth + SidePadding, RawHeight + SidePadding);// 产生一个灰度底图。
            IntPtr NewintPtr = GetPtr.GetImgIntPtr(bitmap, out BitmapData NewbitmapData); //得到指针或者句柄，这是一个C#平台指定的类型。

            int IWidth = bitmapData.Width;


            int InnerHeight = NewbitmapData.Height;
            int InnerWidth = NewbitmapData.Width;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            unsafe
            {
                try
                {
                    byte* RawPoint = (byte*)intPtr.ToPointer();
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();

                    Parallel.For(0, RawHeight, options, i => {
                        for (int j = 0; j < RawWidth; j++)
                        {
                            int Innner_offset = (i + PaddingPixels) * NewbitmapData.Stride + (j + PaddingPixels);
                            int RawOffset = i * bitmapData.Stride + j;
                            DestPointer[Innner_offset] = RawPoint[RawOffset];
                        }
                    });
                    RawBitmap.UnlockBits(bitmapData); //释放原始图片的资源占用。
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Assign Array Pointer:" + ex.Message);
                }
                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width;
                    Parallel.For(0, NewbitmapData.Height, options, i=> {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补上部空缺
                            if (i < PaddingPixels && j > 0 && j < InnerWidth - PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j; // 当前空值
                                int Padding_offset = (-i + PaddingPixels * 2) * NewbitmapData.Stride + j;

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = InnerValue;
                            }
                        }
                    });


                    Parallel.For(0, NewbitmapData.Height, options, i =>
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补下部空缺
                            if (i > (InnerHeight - PaddingPixels))
                            {
                                int boundary = InnerHeight - PaddingPixels;
                                int Innner_offset = (i - 2) * NewbitmapData.Stride + j;//当前空值坐标
                                int Padding_offset = (-i + 2 * boundary-2) * NewbitmapData.Stride + j; // 提取的目标数据

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = InnerValue;
                            }
                            //填补左侧空缺
                            else if (i >= 0 && i < InnerHeight && j < PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (-j + 2 * PaddingPixels); //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = InnerValue;
                            }
                            //填补右侧空缺
                            else if (i >= 0 && i < InnerHeight && j > (InnerWidth - PaddingPixels))
                            {
                                int boundary = InnerWidth - PaddingPixels;
                                int Innner_offset = i * NewbitmapData.Stride + (j-2); //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (-j + 2 * boundary-2); //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = InnerValue;
                            }
                        }
                    });
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Padding Pointer:" + ex.Message);
                }
            }

            bitmap.UnlockBits(NewbitmapData);
            return bitmap;
        }


        /// <summary>
        /// Cuts the image, 3 channels.
        /// </summary>
        /// <returns>The image.</returns>
        /// <param name="SourceImg">Source image.</param>
        /// <param name="rectangle">Rectangle.</param>
        public unsafe Bitmap Cut3CImg(Bitmap SourceImg, Rectangle rectangle)
        {
            Bitmap DestImg = new Bitmap(rectangle.Width, rectangle.Height, SourceImg.PixelFormat);
            IntPtr DintPtr = GetPtr.GetImgIntPtr(DestImg, out BitmapData DBdata);
            IntPtr intPtr = GetPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);

            Point StartPoint = rectangle.Location;
            byte* SPoint = (byte*)intPtr.ToPointer();
            byte* Dpoint = (byte*)DintPtr.ToPointer();
            int StartY = StartPoint.Y;
            int StartX = StartPoint.X;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, DestImg.Height, options, i => {
                for (int j = 0; j < DestImg.Width; j++)
                {
                    int Doffset = DBdata.Stride * i + j * 3;
                    int Soffset = SBdata.Stride * (i + StartY) + (j + StartX) * 3;
                    Dpoint[Doffset] = SPoint[Soffset];
                    Dpoint[Doffset + 1] = SPoint[Soffset + 1];
                    Dpoint[Doffset + 2] = SPoint[Soffset + 2];
                }
            });

            SourceImg.UnlockBits(SBdata);
            DestImg.UnlockBits(DBdata);
            return DestImg;
        }


        /// <summary>
        /// Cut1s the image, 1 channel.
        /// </summary>
        /// <returns>The CI mg.</returns>
        /// <param name="SourceImg">Source image.</param>
        /// <param name="rectangle">Rectangle.</param>
        public unsafe Bitmap Cut1CImg(Bitmap SourceImg, Rectangle rectangle)
        {
            CreateGrayBitmap CreateGray = new CreateGrayBitmap();
            Bitmap DestImg = CreateGray.GetGrayBitmap(rectangle.Width, rectangle.Height);

            //Bitmap DestImg = new Bitmap(rectangle.Width, rectangle.Height, SourceImg.PixelFormat);
            IntPtr DintPtr = GetPtr.GetImgIntPtr(DestImg, out BitmapData DBdata);
            IntPtr intPtr = GetPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);

            Point StartPoint = rectangle.Location;
            byte* SPoint = (byte*)intPtr.ToPointer();
            byte* Dpoint = (byte*)DintPtr.ToPointer();
            int StartY = StartPoint.Y;
            int StartX = StartPoint.X;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, DestImg.Height, options, i => {
                {
                    for (int j = 0; j < DestImg.Width; j++)
                    {
                        int Doffset = DBdata.Stride * i + j ;
                        int Soffset = SBdata.Stride * (i + StartY) + (j + StartX);
                        Dpoint[Doffset] = SPoint[Soffset];
                    }
                }
            });

            SourceImg.UnlockBits(SBdata);
            DestImg.UnlockBits(DBdata);
            return DestImg;
        }


        /// <summary>
        /// GrayScale images the to 2D Byte array.
        /// </summary>
        /// <returns>The to2 DB yte array.</returns>
        /// <param name="bmp">Bmp.</param>
        public static byte[,] ImageTo2DByteArray(Bitmap bmp)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            Rectangle rectangle = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rectangle, ImageLockMode.ReadWrite, bmp.PixelFormat);

            byte[] bytes = new byte[height * data.Stride];
            try
            {
                Marshal.Copy(data.Scan0, bytes, 0, bytes.Length);
            }
            finally
            {
                bmp.UnlockBits(data);
            }

            byte[,] result = new byte[height, width];
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                {
                    int offset = y * data.Stride + x * 3;
                    result[y, x] = bytes[offset];
                }

            return result;
        }

        /// <summary>
        /// GrayScale images the to 2D Byte array.
        /// </summary>
        /// <returns>The to2 DB yte array.</returns>
        /// <param name="bmp">Bmp.</param>
        public static byte[,] GrayScaleImageTo2DArray(Bitmap bmp)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            Rectangle rectangle = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rectangle, ImageLockMode.ReadWrite, bmp.PixelFormat);

            byte[] bytes = new byte[height * data.Stride];
            try
            {
                Marshal.Copy(data.Scan0, bytes, 0, bytes.Length);
            }
            finally
            {
                bmp.UnlockBits(data);
            }

            byte[,] result = new byte[height, width];
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                {
                    int offset = y * data.Stride + x;
                    result[y, x] = bytes[offset];
                }

            return result;
        }


        public unsafe static (Bitmap, int[,]) Array2Image(int[] ArrayData, int width, 
            int height, int max)
        {

            CreateGrayBitmap CreateGray = new CreateGrayBitmap();
            Bitmap DestImg = CreateGray.GetGrayBitmap(width, height); // 创建灰度图(单通道)

            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr intPtr = getIntPtr.GetImgIntPtr(DestImg, out BitmapData DBdata);
            byte* DesPointer = (byte*)intPtr.ToPointer();

            int[,] DestArray = new int[height, width];
            try
            {
                int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
                var options = new ParallelOptions
                {
                    MaxDegreeOfParallelism = degreeOfParallelism
                };

                Parallel.For(0, height, options, i=> {
                    for (int j = 0; j < width; j++)
                    {
                        DestArray[height - 1 - i, j] = ArrayData[i * width + j];
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Create Hough Image --" + ex.ToString());
            }

            DestImg.UnlockBits(DBdata);
            return (DestImg, DestArray);
        }


        public unsafe static Bitmap Array2Image(int[][] ArrayData, int width, int height)
        {

            CreateGrayBitmap CreateGray = new CreateGrayBitmap();
            Bitmap DestImg = CreateGray.GetGrayBitmap(width, height); // 创建灰度图(单通道)

            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr intPtr = getIntPtr.GetImgIntPtr(DestImg, out BitmapData DBdata);
            byte* DesPointer = (byte*)intPtr.ToPointer();

            int[,] DestArray = new int[height, width];
            try
            {
                int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
                var options = new ParallelOptions
                {
                    MaxDegreeOfParallelism = degreeOfParallelism
                };

                Parallel.For(0, height, options, i => {
                    for (int j = 0; j < width; j++)
                    {
                        DesPointer[i*DBdata.Stride + j] = (byte)ArrayData[i][j];
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Create Hough Image --" + ex.ToString());
            }

            DestImg.UnlockBits(DBdata);
            return DestImg;
        }



        public unsafe static int[,] Array2DArray(int[] ArrayData, int width, int height, int max)
        {
            int[,] ResultArray = new int[height, width];

            try
            {
                int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
                var options = new ParallelOptions
                {
                    MaxDegreeOfParallelism = degreeOfParallelism
                };

                Parallel.For(0, height, options, i => {
                    for (int j = 0; j < width; j++)
                    {
                        //int n = Math.Min((int)Math.Round(ArrayData[i * width + j] * 255.0 / max), 255);
                        //DesPointer[(height - 1 - i) * DBdata.Stride + j] = Convert.ToByte(n);
                        ResultArray[i, j] = ArrayData[i * width + j];
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Create Hough Image --" + ex.ToString());
            }

            //DestImg.UnlockBits(DBdata);
            return ResultArray;
        }

        /// <summary>
        /// Filpings the array. 
        /// </summary>
        /// <returns>The array.</returns>
        /// <param name="Array">Array.</param>
        /// <param name="width">Width.</param>
        /// <param name="height">Height.</param>
        public static int[] FilpingArray(int[] Array,
            int width, int height)
        {
            int[] newArray = new int[Array.Length];

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, height, options, i => {
                for (int j = 0; j < width; j++)
                {
                    newArray[(height - 1 - i) * width + j] = Array[i * width + j];
                }
            });

            return newArray;
        }
    }
}
