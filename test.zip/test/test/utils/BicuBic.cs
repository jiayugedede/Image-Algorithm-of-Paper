﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace test.utils
{
    public class BicuBic
    {
        string log_path = "/home/samzhang/图片/log.txt";

        public BicuBic()
        {
        }

        public IntPtr GetIntPtr(Bitmap bitmap)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData NewbitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            IntPtr NewintPtr = NewbitmapData.Scan0;
            return NewintPtr;
        }

        public IntPtr GetIntPtr(Bitmap bitmap, out BitmapData bitmapData)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            bitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            IntPtr NewintPtr = bitmapData.Scan0;
            return NewintPtr;
        }

        /// <summary>
        /// 有问题，暂时无法修复
        /// 扩增图片，同时填充边缘为0
        /// </summary>
        /// <returns>The edge.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// <param name="PaddingPixels"> number of padding pixels.</param>
        public Bitmap PaddingEdge(Bitmap RawBitmap, int PaddingPixels)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);
            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址

            int SidePadding = PaddingPixels * 2; //不一定能用的上

            Bitmap bitmap = new Bitmap(RawBitmap.Width+ SidePadding, RawBitmap.Height + SidePadding, RawBitmap.PixelFormat);
            BitmapData NewbitmapData;
            IntPtr NewintPtr = GetIntPtr(bitmap, out NewbitmapData); //得到指针或者句柄，这是一个C#平台指定的类型。

            int IWidth = bitmapData.Width;
            RawBitmap.UnlockBits(bitmapData);
            byte[,] SourceImageArray = ImageTo2DByteArray(RawBitmap);
            //RawBitmap.UnlockBits(bitmapData);
            int InnerHeight = NewbitmapData.Height;
            int InnerWidth = NewbitmapData.Width;
            unsafe
            {
                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 128;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {


                            if ((i >= PaddingPixels && i < NewbitmapData.Height - PaddingPixels) && (j >= PaddingPixels && j < NewbitmapData.Width - PaddingPixels))
                            {
                                //这样写不能在最后加offset。
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;
                                InnerValue = SourceImageArray[i-PaddingPixels, j-PaddingPixels];
                                DestPointer[Innner_offset + 0] = DestPointer[Innner_offset+1] = DestPointer[Innner_offset+2] = InnerValue;
                            }
                        }
                        //string LogStr = i.ToString();
                        //Tools.WriteByLine(log_path, LogStr);

                        // Please note
                        // 如果使用 height*Stride + widthIndex* 3的方式就不能再加offset。
                        // DestPointer += offset; 
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Assign Array Pointer:" + ex.Message);
                }


                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补上部空缺
                            if (i < PaddingPixels && j > PaddingPixels && j < InnerWidth - PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; // 当前空值
                                int Padding_offset = (i + PaddingPixels) * NewbitmapData.Stride + j * 3;

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补下部空缺
                            else if (i > InnerHeight - Math.Ceiling(1.5 * PaddingPixels))
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;//当前空值
                                int Padding_offset = (i - PaddingPixels) * NewbitmapData.Stride + j * 3; // 提取的目标数据

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补左侧空缺
                            else if (i >= 0 && i < InnerHeight && j < PaddingPixels)
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (j + PaddingPixels) * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补右侧空缺
                            else if (i >= 0 && i < InnerHeight && j > InnerWidth - Math.Ceiling(1.5 * PaddingPixels))
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = Innner_offset - PaddingPixels * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Padding Pointer:" + ex.Message);
                }
            }
            bitmap.UnlockBits(NewbitmapData);
            return bitmap;
        }

        /// <summary>
        /// Images the to 2D Byte array.
        /// </summary>
        /// <returns>The to2 DB yte array.</returns>
        /// <param name="bmp">Bmp.</param>
        public static byte[,] ImageTo2DByteArray(Bitmap bmp)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            Rectangle rectangle = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rectangle, ImageLockMode.ReadWrite, bmp.PixelFormat);

            byte[] bytes = new byte[height * data.Stride];
            try
            {
                Marshal.Copy(data.Scan0, bytes, 0, bytes.Length);
            }
            finally
            {
                bmp.UnlockBits(data);
            }

            byte[,] result = new byte[height, width];
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                {
                    int offset = y * data.Stride + x * 3;
                    result[y, x] = bytes[offset + 0];
                }

            return result;
        }

        /// <summary>
        /// 扩增图片，同时填充边缘为0。
        /// </summary>
        /// <returns>The edge.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// <param name="PaddingPixels">Padding pixels number.</param>
        /// <param name="PaddingValue">Padding pixels value.</param>
        public Bitmap PaddingEdge(Bitmap RawBitmap, int PaddingPixels, byte PaddingValue)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);
            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址

            int SidePadding = PaddingPixels * 2; //不一定能用的上

            Bitmap bitmap = new Bitmap(RawBitmap.Width + SidePadding, RawBitmap.Height + SidePadding, RawBitmap.PixelFormat);
            BitmapData NewbitmapData;
            IntPtr NewintPtr = GetIntPtr(bitmap, out NewbitmapData); //得到指针或者句柄，这是一个C#平台指定的类型。

            RawBitmap.UnlockBits(bitmapData);
            byte[,] SourceImageArray = ImageTo2DByteArray(RawBitmap);

            //先给新图片设置底色
            unsafe
            {
                int Innner_offset = 0;
                byte* ptr = (byte*)NewintPtr;
                var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                for (int i = 0; i < NewbitmapData.Height; i++)
                {
                    for (int j = 0; j < NewbitmapData.Width; j++)
                    {
                        Innner_offset = i * NewbitmapData.Stride + j * 3;
                        ptr[Innner_offset+0] = ptr[Innner_offset+1] = ptr[Innner_offset+2] = PaddingValue;
                    }
                }
            }// padding图片的底色设置完成

            int InnerHeight = NewbitmapData.Height;
            int InnerWidth = NewbitmapData.Width;

            unsafe
            {
                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            if ((i >= PaddingPixels && i < NewbitmapData.Height - PaddingPixels) && (j >= PaddingPixels && j < NewbitmapData.Width - PaddingPixels))
                            {
                                //这样写不能在最后加offset。
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;
                                InnerValue = SourceImageArray[i - PaddingPixels, j - PaddingPixels];
                                DestPointer[Innner_offset + 0] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                        //string LogStr = i.ToString();
                        //Tools.WriteByLine(log_path, LogStr);
                        // Please note
                        // 如果使用 height*Stride + widthIndex* 3的方式就不能再加offset。
                        // DestPointer += offset; 
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Assign Array Pointer:" + ex.Message);
                }

                try
                {
                    byte* DestPointer = (byte*)NewintPtr.ToPointer();
                    byte InnerValue = 0;
                    var offset = NewbitmapData.Stride - NewbitmapData.Width * 3;
                    for (int i = 0; i < NewbitmapData.Height; i++)
                    {
                        for (int j = 0; j < NewbitmapData.Width; j++)
                        {
                            //填补上部空缺
                            if (i < PaddingPixels)
                            {
                                int Diffience = PaddingPixels - i;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; // 当前空值
                                int Padding_offset = (PaddingPixels + Diffience-1) * NewbitmapData.Stride + j * 3; //目标值

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补下部空缺
                            else if (i > InnerHeight- Convert.ToInt32(Math.Ceiling(1.4 * PaddingPixels)))
                            {
                                int Diffience = i + PaddingPixels - InnerHeight;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3;//当前空值
                                int Padding_offset = (i - PaddingPixels - Diffience) * NewbitmapData.Stride + j * 3; // 提取的目标数据

                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补左侧空缺
                            else if (j < PaddingPixels)
                            {
                                int Diffience = PaddingPixels - j;
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = i * NewbitmapData.Stride + (PaddingPixels + Diffience) * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                            //填补右侧空缺
                            else if (i >= 0 && i < InnerHeight && j > InnerWidth - Math.Ceiling(1.5*PaddingPixels))
                            {
                                int Innner_offset = i * NewbitmapData.Stride + j * 3; //当前空值
                                int Padding_offset = Innner_offset - PaddingPixels * 3; //提取的目标值
                                InnerValue = DestPointer[Padding_offset ];
                                DestPointer[Innner_offset] = DestPointer[Innner_offset + 1] = DestPointer[Innner_offset + 2] = InnerValue;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Padding Pointer:" + ex.Message);
                }

            }
            bitmap.UnlockBits(NewbitmapData);
            return bitmap;
        }



        /// <summary>
        /// Converts the color to gray.
        /// </summary>
        /// <returns>The color to gray.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        public Bitmap ConvertColorToGray(Bitmap RawBitmap)
        {
            Rectangle rectangle = new Rectangle(0, 0, RawBitmap.Width, RawBitmap.Height);
            BitmapData bitmapData = RawBitmap.LockBits(rectangle, ImageLockMode.ReadWrite, RawBitmap.PixelFormat);

            IntPtr intPtr = bitmapData.Scan0; //bitmap首地址
            Bitmap bitmap = new Bitmap(RawBitmap.Width, RawBitmap.Height, RawBitmap.PixelFormat);
            BitmapData GrayBitmapData;
            IntPtr GrayIntPtr = GetIntPtr(bitmap, out GrayBitmapData);

            unsafe
            {
                byte temp = 0;
                byte* ptr = (byte*)GrayIntPtr;
                byte* old_ptr = (byte*)intPtr;
                for (int i = 0; i < GrayBitmapData.Height; i++)
                {
                    for (int j = 0; j < GrayBitmapData.Width; j++)
                    {
                        temp = (byte)(0.114 * old_ptr[0] + 0.587 * old_ptr[1] +  0.299 * old_ptr[2]);
                        ptr[0] = ptr[1] = ptr[2] = temp;
                        ptr += 3; 
                        old_ptr += 3;
                    }
                    ptr += GrayBitmapData.Stride - GrayBitmapData.Width*3; //系统对齐，这个源自于图片格式造成的数据空余空间对齐机制。
                    old_ptr += bitmapData.Stride - bitmapData.Width * 3;
                }
            }
            bitmap.UnlockBits(GrayBitmapData); //解锁锁定的字节数据
            RawBitmap.UnlockBits(bitmapData);
            return bitmap;
        }

        /// <summary>
        /// 完成图像双三次插值
        /// 清晰图片不要用插值，效果不好。
        /// </summary>
        /// <returns>The get.</returns>
        /// <param name="RawBitmap">Raw bitmap.</param>
        /// a[x,y] = a[0,0]x^0 y^0 + a[0,1] x^0 y^1 + a[0,2] x^0 y^2 + a[0,3] x^0 y^3 +
        ///          a[1,0]x^1 y^0 + a[1,1] x^1 y^1 + a[1,2] x^1 y^2 + a[1,3] x^1 y^3 +
        ///          a[2,0]x^2 y^0 + a[2,1] x^2 y^1 + a[2,2] x^2 y^2 + a[2,3] x^2 y^3 +
        ///          a[3,0]x^3 y^0 + a[3,1] x^3 y^1 + a[3,2] x^3 y^2 + a[3,3] x^3 y^3
        public Bitmap Bicubic(Bitmap RawBitmap)
        {
            BitmapData bitmapData;
            IntPtr intPtr =  GetIntPtr(RawBitmap, out bitmapData);
            int bytes = bitmapData.Height * bitmapData.Width*3;
            byte[] rgbValues = new byte[bytes];

            System.Runtime.InteropServices.Marshal.Copy(intPtr, rgbValues, 0, bytes);

            Bitmap CopyBitmap = new Bitmap(RawBitmap.Width, RawBitmap.Height, RawBitmap.PixelFormat);
            BitmapData CopyBitmapData;
            IntPtr CopyPtr = GetIntPtr(CopyBitmap, out CopyBitmapData);

            int IHeight = bitmapData.Height;
            int IWidth = bitmapData.Width;
            int Strid = bitmapData.Stride;

            //byte Result = 0;

            //这里使用指针进行图像数据调区。
            unsafe
            {
                byte Result = 0;
                byte* ptr = (byte*)intPtr.ToPointer();
                byte* CopyPtrPointer = (byte*)CopyPtr.ToPointer();
                var offset = bitmapData.Stride - IWidth * 3;
                for (int i = 0; i < bitmapData.Height; i++)
                {
                    double v = Convert.ToDouble(i) / (RawBitmap.Height - 1);
                    for (int j = 0; j < bitmapData.Width; j++)
                    {
                        if ((i>=2&& i< bitmapData.Height-2) && (j>=2&&j<=bitmapData.Width-2))
                        {
                            double u = Convert.ToDouble(j) / (RawBitmap.Width - 1);
                            int SourceOffset = i * bitmapData.Stride + j * 3;
                            Result = ComputeValue(ptr, SourceOffset, bitmapData, u, v);
                            int CopyOffset = i * CopyBitmapData.Stride + j * 3;
                            CopyPtrPointer[CopyOffset] = CopyPtrPointer[CopyOffset+1] = CopyPtrPointer[CopyOffset+2] = Result;
                        }
                    }
                }
            }
            RawBitmap.UnlockBits(bitmapData);
            CopyBitmap.UnlockBits(CopyBitmapData);
            return CopyBitmap; //临时设定
        }


        /// <summary>
        /// 使用双三次核公式，计算十六格，并加权.
        /// </summary>
        /// <returns>The value.</returns>
        /// <param name="p">P.</param>
        /// <param name="bitmapData">Bitmap data.</param>
        /// <param name="u">U.</param>
        /// <param name="v">V.</param>
        public unsafe byte ComputeValue(byte* p, int offset, BitmapData bitmapData, double u, double v)
        {
            int UOffset = offset - bitmapData.Stride;
            int UValue_0 = p[UOffset-3];
            int UValue_1 = p[UOffset];
            int UValue_2 = p[UOffset+3];
            int UValue_3 = p[UOffset+6];

            int CValue_0 = p[offset-3];
            int CValue_1 = p[offset];
            int CValue_2 = p[offset + 3];
            int CValue_3 = p[offset + 6];

            int SPointer = offset + bitmapData.Stride;
            int SValue_0 = p[SPointer - 3];
            int SValue_1 = p[SPointer];
            int SValue_2 = p[SPointer + 3];
            int SValue_3 = p[SPointer + 6];

            int TPointer = SPointer + bitmapData.Stride;
            int TValue_0 = p[TPointer - 3];
            int TValue_1 = p[TPointer];
            int TValue_2 = p[TPointer + 3];
            int TValue_3 = p[TPointer + 6];

            double x = (u * bitmapData.Width) - 0.5;
            int xint = Convert.ToInt32(x);
            double xfract = x - Math.Floor(x);

            double y = (v * bitmapData.Height) - 0.5;
            int yint = Convert.ToInt32(y);
            double yfract = y - Math.Floor(y);

            double col0 = CubicHermite(UValue_0, UValue_1, UValue_2, UValue_3, xfract);
            double col1 = CubicHermite(CValue_0, CValue_1, CValue_2, CValue_3, xfract);
            double col2 = CubicHermite(SValue_0, SValue_0, SValue_0, SValue_0, xfract);
            double col3 = CubicHermite(TValue_0, TValue_0, TValue_0, TValue_0, xfract);
            double value = CubicHermite(col0, col1, col2, col3, yfract);
            double Result = CLAMP(value, 0.0d, 255.0d);
            return Convert.ToByte(Result);
        }

        //双三次赫密特计算公式。
        public double CubicHermite(float A, float B, float C, float D, double t)
        {
            float a = -A / 2.0f + (3.0f * B) / 2.0f - (3.0f * C) / 2.0f + D / 2.0f;
            float b = A - (5.0f * B) / 2.0f + 2.0f * C - D / 2.0f;
            float c = -A / 2.0f + C / 2.0f;
            float d = B;
            double Result = a * t * t * t + b * t * t + c * t + d;
            return Result;
        }


        /// <summary>
        /// 双三次赫密特计算公式。
        /// </summary>
        /// <returns>The hermite.</returns>
        /// <param name="A">A.</param>
        /// <param name="B">B.</param>
        /// <param name="C">C.</param>
        /// <param name="D">D.</param>
        /// <param name="t">T.</param>
        public double CubicHermite(double A, double B, double C, double D, double t)
        {
            double a = -A / 2.0f + (3.0f * B) / 2.0f - (3.0f * C) / 2.0f + D / 2.0f;
            double b = A - (5.0f * B) / 2.0f + 2.0f * C - D / 2.0f;
            double c = -A / 2.0f + C / 2.0f;
            double d = B;
            double Result = a * t * t * t + b * t * t + c * t + d;
            return Result;
        }


        /// <summary>
        /// Clamp the specified v, min and max.
        /// </summary>
        /// <returns>The clamp.</returns>
        /// <param name="v">V.</param>
        /// <param name="min">Minimum.</param>
        /// <param name="max">Max.</param>
        public double CLAMP(double v, double min, double max)
        {
            if (v<=min)
            {
                v = min;
            }
            else if (v>=max)
            {
                v = max;
            }
            return v;
        }


        public Bitmap ResizeBitmap(Bitmap bmp, int width, int height)
        {
            Bitmap result = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.DrawImage(bmp, 0, 0, width, height);
            }
            Rectangle rectangle = new Rectangle(0,0, result.Width, result.Height);
            Bitmap DestBmp = result.Clone(rectangle, result.PixelFormat);
            return DestBmp;
        }
    }
}
