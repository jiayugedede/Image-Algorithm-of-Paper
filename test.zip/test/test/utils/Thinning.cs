﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test.utils
{
    public class Thinning
    {
        public string log_path = "/home/samzhang/图片/log.txt";
        private GetIntPtr getIntPtr = new GetIntPtr();



        public Thinning()
        {
        }

        public static unsafe Bitmap ToThinner(Bitmap srcImg)
        {

            int iw = srcImg.Width;

            int ih = srcImg.Height;



            bool bModified;//Binary image modification flag

            bool bCondition1;//refine condition 1 flag

            bool bCondition2;//refine condition 2 flag

            bool bCondition3;//refine condition 3 flag

            bool bCondition4;//refine condition 4 flag



            int nCount;



            //5X5 pixel block

            byte[,] neighbour = new byte[5, 5];

            //Create a new temporary storage image

            Bitmap NImg = new Bitmap(iw, ih, srcImg.PixelFormat);



            bModified = true;//refine the modification flag, used as a loop condition



            BitmapData dstData = srcImg.LockBits(new Rectangle(0, 0, iw, ih), ImageLockMode.ReadWrite, srcImg.PixelFormat);

            byte* data = (byte*)(dstData.Scan0);

            //Convert the image to a value of 0,1;

            int step = dstData.Stride;

            for (int i = 0; i < dstData.Height; i++)

            {

                for (int j = 0; j < dstData.Width; j++)

                {

                    if (data[i * step + j] > 128)

                        data[i * step + j] = 0;

                    else

                        data[i * step + j] = 1;

                }

            }



            BitmapData dstData1 = NImg.LockBits(new Rectangle(0, 0, iw, ih), ImageLockMode.ReadWrite, NImg.PixelFormat);

            byte* data1 = (byte*)(dstData1.Scan0);

            int step1 = dstData1.Stride;

            //Refinement cycle begins

            while (bModified)

            {

                bModified = false;



                //Initialize temporary binary image NImg

                for (int i = 0; i < dstData1.Height; i++)
                {
                    for (int j = 0; j < dstData1.Width; j++)
                    {
                        data1[i * step1 + j] = 0;
                    }
                }



                for (int i = 2; i < ih - 2; i++)
                {
                    for (int j = 2; j < iw - 2; j++)
                    {
                        bCondition1 = false;
                        bCondition2 = false;
                        bCondition3 = false;
                        bCondition4 = false;

                        if (data[i * step + j] == 0)//If the current point of the image is white, skip
                            continue;
                        for (int k = 0; k < 5; k++)
                        {
                            //Take a 5X5 block centered on the current point
                            for (int l = 0; l < 5; l++)
                            {
                                //1 stands for black, 0 stands for white
                                //neighbour[k, l] = bw[i + k-2, j + l-2];
                                neighbour[k, l] = data[(i + k - 2) * step + (j + l - 2)];
                            }

                        }



                        //(1) Judgment condition 2<=n(p)<=6

                        nCount = neighbour[1, 1] + neighbour[1, 2] + neighbour[1, 3] +

                                 neighbour[2, 1] + neighbour[2, 3] +

                                 neighbour[3, 1] + neighbour[3, 2] + neighbour[3, 3];

                        if (nCount >= 2 && nCount <= 6)

                            bCondition1 = true;

                        else

                        {

                            data1[i * step1 + j] = 1;

                            continue;//Skip, speed up

                        }



                        //(2) judge s(p)=1

                        nCount = 0;

                        if (neighbour[2, 3] == 0 && neighbour[1, 3] == 1)

                            nCount++;

                        if (neighbour[1, 3] == 0 && neighbour[1, 2] == 1)

                            nCount++;

                        if (neighbour[1, 2] == 0 && neighbour[1, 1] == 1)

                            nCount++;

                        if (neighbour[1, 1] == 0 && neighbour[2, 1] == 1)

                            nCount++;

                        if (neighbour[2, 1] == 0 && neighbour[3, 1] == 1)

                            nCount++;

                        if (neighbour[3, 1] == 0 && neighbour[3, 2] == 1)

                            nCount++;

                        if (neighbour[3, 2] == 0 && neighbour[3, 3] == 1)

                            nCount++;

                        if (neighbour[3, 3] == 0 && neighbour[2, 3] == 1)

                            nCount++;

                        if (nCount == 1)

                            bCondition2 = true;

                        else

                        {

                            data1[i * step1 + j] = 1;

                            continue;

                        }



                        //(3)Judge p0*p2*p4=0 or s(p2)!=1

                        if (neighbour[2, 3] * neighbour[1, 2] * neighbour[2, 1] == 0)

                            bCondition3 = true;

                        else

                        {

                            nCount = 0;

                            if (neighbour[0, 2] == 0 && neighbour[0, 1] == 1)

                                nCount++;

                            if (neighbour[0, 1] == 0 && neighbour[1, 1] == 1)

                                nCount++;

                            if (neighbour[1, 1] == 0 && neighbour[2, 1] == 1)

                                nCount++;

                            if (neighbour[2, 1] == 0 && neighbour[2, 2] == 1)

                                nCount++;

                            if (neighbour[2, 2] == 0 && neighbour[2, 3] == 1)

                                nCount++;

                            if (neighbour[2, 3] == 0 && neighbour[1, 3] == 1)

                                nCount++;

                            if (neighbour[1, 3] == 0 && neighbour[0, 3] == 1)

                                nCount++;

                            if (neighbour[0, 3] == 0 && neighbour[0, 2] == 1)

                                nCount++;

                            if (nCount != 1)//s(p2)!=1

                                bCondition3 = true;

                            else

                            {

                                data1[i * step1 + j] = 1;

                                continue;

                            }

                        }



                        //(4) judge p2*p4*p6=0 or s(p4)!=1

                        if (neighbour[1, 2] * neighbour[2, 1] * neighbour[3, 2] == 0)

                            bCondition4 = true;

                        else

                        {

                            nCount = 0;

                            if (neighbour[1, 1] == 0 && neighbour[1, 0] == 1)

                                nCount++;

                            if (neighbour[1, 0] == 0 && neighbour[2, 0] == 1)

                                nCount++;

                            if (neighbour[2, 0] == 0 && neighbour[3, 0] == 1)

                                nCount++;

                            if (neighbour[3, 0] == 0 && neighbour[3, 1] == 1)

                                nCount++;

                            if (neighbour[3, 1] == 0 && neighbour[3, 2] == 1)

                                nCount++;

                            if (neighbour[3, 2] == 0 && neighbour[2, 2] == 1)

                                nCount++;

                            if (neighbour[2, 2] == 0 && neighbour[1, 2] == 1)

                                nCount++;

                            if (neighbour[1, 2] == 0 && neighbour[1, 1] == 1)

                                nCount++;

                            if (nCount != 1)//s(p4)!=1

                                bCondition4 = true;



                        }

                        if (bCondition1 && bCondition2 && bCondition3 && bCondition4)

                        {

                            data1[i * step1 + j] = 0;

                            bModified = true;

                        }

                        else

                        {

                            data1[i * step1 + j] = 1;

                        }

                    }

                }



                //Copy the refined temporary image bw_tem[w,h] to bw[w,h] to complete a refinement

                for (int i = 2; i < ih - 2; i++)

                    for (int j = 2; j < iw - 2; j++)

                        data[i * step + j] = data1[i * step1 + j];

            }



            for (int i = 2; i < ih - 2; i++)

            {

                for (int j = 2; j < iw - 2; j++)

                {

                    if (data[i * step + j] == 1)

                        data[i * step + j] = 0;

                    else

                        data[i * step + j] = 255;

                }

            }

            srcImg.UnlockBits(dstData);

            NImg.UnlockBits(dstData1);

            return srcImg;

        }
    }
}
