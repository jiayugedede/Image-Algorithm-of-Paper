﻿using System;
namespace test.utils
{
    public class ErodeAndDilate
    {
        public ErodeAndDilate()
        {
        }


    }
}
