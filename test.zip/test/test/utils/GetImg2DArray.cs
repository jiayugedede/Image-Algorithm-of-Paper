﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace test.utils
{
    public class GetImg2DArray
    {
        public GetImg2DArray()
        {
        }
        /// <summary>
        /// Images the to 2D Byte array.
        /// </summary>
        /// <returns>The to2 DB yte array.</returns>
        /// <param name="bmp">Bmp.</param>
        public static byte[,] ImageTo2DByteArray(Bitmap bmp)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            Rectangle rectangle = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rectangle, ImageLockMode.ReadWrite, bmp.PixelFormat);

            byte[] bytes = new byte[height * data.Stride];
            try
            {
                Marshal.Copy(data.Scan0, bytes, 0, bytes.Length);
            }
            finally
            {
                bmp.UnlockBits(data);
            }

            byte[,] result = new byte[height, width];
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                {
                    int offset = y * data.Stride + x * 3;
                    result[y, x] = bytes[offset + 0];
                }

            return result;
        }
    }
}
