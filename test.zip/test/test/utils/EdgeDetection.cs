﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace test.utils
{
    public class EdgeDetection
    {
        string log_path = "/home/samzhang/图片/log.txt";

        public EdgeDetection()
        {
        }

        public Bitmap Filter2(Bitmap SourceBitmap)
        {
            Bitmap bmp1 = SourceBitmap;
            Size s1 = bmp1.Size;
            Bitmap bmp2 = new Bitmap(s1.Width, s1.Height);

            PixelFormat fmt1 = bmp1.PixelFormat;

            Rectangle rect = new Rectangle(0, 0, s1.Width, s1.Height);
            BitmapData bmpData1 = bmp1.LockBits(rect, ImageLockMode.ReadOnly, fmt1);
            BitmapData bmpData2 = bmp2.LockBits(rect, ImageLockMode.WriteOnly, fmt1);
            byte bpp = 4;  // set to 3 for 24bbp !!

            int size1 = bmpData1.Stride * bmpData1.Height;
            byte[] data1 = new byte[size1];
            byte[] data2 = new byte[size1];
            Marshal.Copy(bmpData1.Scan0, data1, 0, size1);
            Marshal.Copy(bmpData2.Scan0, data2, 0, size1);

            int degreeOfParallelism = Environment.ProcessorCount - 1;
            var options = new ParallelOptions();
            options.MaxDegreeOfParallelism = degreeOfParallelism;

            Parallel.For(0, bmp1.Width, options, y =>
            {
                {
                    for (int x = 0; x < s1.Width; x++)
                    {
                        int index = y * bmpData1.Stride + x * bpp;

                        data2[index + 0] = (byte)(255 - data1[index + 0]);  // Blue
                        data2[index + 1] = (byte)(255 - data1[index + 1]);  // Green
                        data2[index + 2] = (byte)(255 - data1[index + 2]);  // Red
                        data2[index + 3] = 255;   // Alpha, comment out for 24 bpp!
                    }
                }
            });
            Marshal.Copy(data2, 0, bmpData2.Scan0, data2.Length);
            bmp1.UnlockBits(bmpData1);
            bmp2.UnlockBits(bmpData2);
            return bmp2;
        }



        /// <summary>
        /// Sobels the edge detection.
        /// </summary>
        /// <returns>The edge detection.</returns>
        /// <param name="SourceBitmap">Source bitmap.</param>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Bitmap SobelEdgeDetection(Bitmap SourceBitmap)
        {
            List<BaseStruct> baseStructsLink = new List<BaseStruct>();
            Bitmap DestBitmap = new Bitmap(SourceBitmap.Width, 
                                           SourceBitmap.Height, 
                                           SourceBitmap.PixelFormat); //创建一张新的bitmap图片，底色是255
            Tools tools = new Tools();
            // 获取图像存储首地址
            IntPtr SourcePtr = tools.GetIntPtr(SourceBitmap, out BitmapData SourceBdata, ImageLockMode.ReadOnly);
            byte SobelGradient = 0;
            IntPtr DestPtr = tools.GetIntPtr(DestBitmap, out BitmapData DestBdata, ImageLockMode.WriteOnly);
            int degreeOfParallelism = Environment.ProcessorCount - 1; // 获取环境中可申请的thread的数量。
            var options = new ParallelOptions();

            unsafe byte GetSobelGradientValue(byte* SourceIntPtr, int SourceOffset, BitmapData SourceBitmapData)
            {
                byte ResultSobelGradient = 0;
                byte[,] SobelGradientArray = { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };
                GetPixelValueToMatrix(SourceIntPtr, SourceOffset, SourceBitmapData, ref SobelGradientArray);
                SobelEdgeGradient(SobelGradientArray, ref ResultSobelGradient);
                SobelGradientArray = null; //把寄存数组置为null。

                return ResultSobelGradient;
            }

            unsafe void GetPixelValueToMatrix(byte* SourceIntPtr, int SourceOffset, BitmapData SourceBitmapData, ref byte[,] PiexlArray)
            {

                //上方像素
                int UpperOffset = SourceOffset - SourceBitmapData.Stride;
                int SourceLeftUpperIndex = UpperOffset - 3; //左上方数值
                int SourceUpperIndex = UpperOffset; //上方数值
                int SourceUpperRightIndex = UpperOffset + 3;

                byte SourceLeftUpper = SourceIntPtr[SourceLeftUpperIndex];
                PiexlArray[0, 0] = SourceLeftUpper;
                byte SourceUpper = SourceIntPtr[SourceUpperIndex];
                PiexlArray[0, 1] = SourceUpper;
                byte SourceUpperRight = SourceIntPtr[SourceUpperRightIndex];
                PiexlArray[0, 2] = SourceUpperRight;


                //当前行像素
                int COffsetIndex = SourceOffset;
                int CLeftOffSetIndex = SourceOffset - 3;
                int CRightOffsetIndex = SourceOffset + 3;

                byte SourceLeft = SourceIntPtr[CLeftOffSetIndex];
                PiexlArray[1, 0] = SourceLeft;
                byte SourceValue = SourceIntPtr[COffsetIndex];
                PiexlArray[1, 1] = SourceValue;
                byte SourceRight = SourceIntPtr[CRightOffsetIndex];
                PiexlArray[1, 2] = SourceRight;

                //下方行像素
                int UOffsetIndex = SourceOffset + SourceBitmapData.Stride;
                int ULeftIndex = UOffsetIndex - 3;
                int URightIndex = UOffsetIndex + 3;

                byte ULeft = SourceIntPtr[ULeftIndex];
                PiexlArray[2, 0] = ULeft;
                byte UValue = SourceIntPtr[UOffsetIndex];
                PiexlArray[2, 1] = UValue;
                byte URight = SourceIntPtr[URightIndex];
                PiexlArray[2, 2] = URight;
            }


            unsafe
            {
                try
                {
                    int SourceOffset, DestOffset;
                    byte SourceValue; // 用于存储原图像的坐标像素值
                    byte* SourcePointer = (byte*)SourcePtr.ToPointer();
                    byte* DestPointer = (byte*)DestPtr.ToPointer();

                    for (int i = 1; i < SourceBdata.Height - 1; i++)
                    {
                        for (int j = 1; j < SourceBdata.Width - 1; j++)
                        {
                            SourceOffset = i * SourceBdata.Stride + j * 3;
                            DestOffset = i * DestBdata.Stride + j * 3;
                            SourceValue = SourcePointer[SourceOffset];
                            SobelGradient = GetSobelGradientValue(SourcePointer, SourceOffset, SourceBdata);
                            DestPointer[DestOffset] = DestPointer[DestOffset + 1] = DestPointer[DestOffset + 2] = SobelGradient;
                        }
                    }

                }
                catch (Exception ex)
                {
                    Tools.WriteByLine(log_path, "Sobel Pointer:" + ex.Message);
                }

            }
            SourceBitmap.UnlockBits(SourceBdata);
            DestBitmap.UnlockBits(DestBdata);

            return DestBitmap;
        }
        
        // 计算某一位置的sobel结果
        /// <summary>
        /// Sobels the edge gradient.
        /// </summary>
        /// <returns>The edge gradient.</returns>
        /// <param name="SourceNinePixels">Source nine pixels.</param>
        public void SobelEdgeGradient(byte[,] SourceNinePixels, ref byte GradientResult)
        {
            int ArrayRank = SourceNinePixels.Rank + 1;
            int ArrayWidth = SourceNinePixels.GetUpperBound(0) + 1;
            double SqrtTwo = Math.Sqrt(2);
            double[,] Horizontal = { {-1, 0, 1 }, {-SqrtTwo, 0, SqrtTwo }, {-1, 0, 1} };
            double[,] Vertical = { { -1, -SqrtTwo, -1 }, { 0, 0, 0 }, { 1, SqrtTwo, 1 } };

            double Gx = 0d;
            double Gy = 0d;


            for (int i = 0; i < ArrayRank; i++) //将pixel的数值与卷积模板对应相称再相加
            {
                for (int j = 0; j < ArrayWidth; j++)
                {
                    Gx += SourceNinePixels[i, j] * Horizontal[i, j]; // 计算Gx的值。
                    Gy += SourceNinePixels[i, j] * Vertical[i, j]; // 计算Gy的值。
                }
            }

            double Gradient = Math.Sqrt( Gx * Gx + Gy * Gy); // 计算最终的结果
            //Tools.WriteByLine(log_path, "Sobel Pointer:" + Gradient.ToString());

            if (Gradient>=255)
            {
                Gradient = 255;
            }

            GradientResult = Convert.ToByte(Gradient);
        }

    }
}
