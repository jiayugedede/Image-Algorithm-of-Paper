﻿using System;
using System.Drawing;

namespace test.utils
{
    public static class ImagePool
    {
        public static Bitmap SourceImage;
        public static string ImagePath = String.Empty;

        public static Bitmap GenerateBitmap()
        {
            Bitmap bitmap = new Bitmap(ImagePath);
            return bitmap;
        }
    }
}
