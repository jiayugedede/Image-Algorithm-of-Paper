﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.CompilerServices;

namespace test.utils
{
    /// <summary>
    /// Fill hole.
    /// 
    /// Useage:test.utils.FillHole fillHole = new test.utils.FillHole();
    /// Bitmap SingleImg = fillHole.FillImageHole(SobelImage);
    /// </summary>
    public class FillHole
    {
        public Tools tools = new Tools();
        public CreateGrayBitmap SignleGBmapClass = new CreateGrayBitmap();
        GetIntPtr getIntPtr = new GetIntPtr();

        private int SourceWidth { get; set; }
        private int SourceHeight { get; set; }
        public FillHole()
        {
        }

        public FillHole(int Width, int Height)
        {
            SourceWidth = Width;
            SourceHeight = Height;
        }
        public struct Location 
        {
            public int Y;
            public int X;
        }


        /// <summary>
        /// Gets the single channel gray image.
        /// </summary>
        /// <returns>The single gray image.</returns>
        /// <param name="Width">Width.</param>
        /// <param name="Height">Height.</param>
        private Bitmap GetSingleGrayImg(int Width, int Height)
        {
            Bitmap SignleGrayImg = SignleGBmapClass.GetGrayBitmap(Width, Height);
            return SignleGrayImg;
        }


        /// <summary>
        /// Images the edge padding.
        /// </summary>
        /// <returns>The edge padding.</returns>
        /// <param name="SourceImg">Source image.</param>
        /// <param name="PaddingPixels">Padding pixels number.</param>
        /// <param name="PaddingValue">Padding value.</param>
        private Bitmap ImgEdgePadding(Bitmap SourceImg, int PaddingPixels, byte PaddingValue)
        {
            PaddingEdge paddingEdge = new PaddingEdge();
            Bitmap PaddingImg = paddingEdge.PaddingImgEdge(SourceImg, PaddingPixels, PaddingValue);

            return PaddingImg;
        }


        /// <summary>
        /// Floods fill algorithm to the mask image.
        /// 这个操作要迭代好多次，每次结束之后都要将临时图片赋值给原图片。
        /// </summary>
        /// <param name="SourceBmap">Source bmap.</param>
        /// <param name="DPValue">Destination pixel value.</param>
        /// <param name="BGValue">background pixel value.</param>
        private unsafe void FloodFill(Bitmap SourceBmap, byte DPValue, byte BGValue)
        {
            int SWidth = SourceBmap.Width;
            int SHeight = SourceBmap.Height;

            Bitmap maskPaddingImg = SourceBmap.Clone(new Rectangle(0, 0, SWidth, SHeight), SourceBmap.PixelFormat);
            IntPtr SourceIntPtr = getIntPtr.GetImgIntPtr(maskPaddingImg, out BitmapData SourceBData);
            byte* SourcePointer = (byte*)SourceIntPtr.ToPointer(); //原图像的指针
            int SStride = SourceBData.Stride;

            Stack<Location> FloodStack = new Stack<Location>();
            Location location = new Location
            {
                X = 0,
                Y = 0
            };
            FloodStack.Push(location);

            while (FloodStack.Count >0)
            {
                Location FLocal = FloodStack.Pop();
                SourcePointer[FLocal.Y * SStride + FLocal.X] = DPValue;

                if (FLocal.X > 0 && SourcePointer[FLocal.Y * SStride + (FLocal.X-1)]== BGValue)
                {
                    SourcePointer[FLocal.Y * SStride + (FLocal.X - 1)] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X - 1,
                        Y = FLocal.Y
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.X < SWidth-1 && SourcePointer[FLocal.Y * SStride + (FLocal.X + 1) ] == BGValue)
                {
                    SourcePointer[FLocal.Y * SStride + (FLocal.X + 1) ] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X + 1,
                        Y = FLocal.Y
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.Y > 0 && SourcePointer[(FLocal.Y-1) * SStride + FLocal.X] == BGValue)
                {
                    SourcePointer[(FLocal.Y - 1) * SStride + FLocal.X] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X,
                        Y = FLocal.Y - 1
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.Y < SHeight-1 && SourcePointer[(FLocal.Y+1)*SStride + FLocal.X]== BGValue)
                {
                    SourcePointer[(FLocal.Y + 1) * SStride + FLocal.X] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X,
                        Y = FLocal.Y + 1
                    };
                    FloodStack.Push(Innerlocation);
                }
            }

            FloodStack.Clear(); // 清空栈内内容。
            SourceBmap.UnlockBits(SourceBData);
        }


        /// <summary>
        /// Floods fill algorithm to the mask image.
        /// 这个操作要迭代好多次，每次结束之后都要将临时图片赋值给原图片。
        /// </summary>
        /// <param name="SourceBmap">Source bmap.</param>
        /// <param name="DPValue">Destination pixel value.</param>
        /// <param name="BGValue">background pixel value.</param>
        private unsafe Bitmap FloodFill(Bitmap SourceBmap, byte DPValue, byte BGValue, bool _isReuse)
        {
            int SWidth = SourceBmap.Width;
            int SHeight = SourceBmap.Height;

            Bitmap maskPaddingImg = SourceBmap.Clone(new Rectangle(0, 0, SWidth, SHeight), SourceBmap.PixelFormat);
            IntPtr SourceIntPtr = getIntPtr.GetImgIntPtr(maskPaddingImg, out BitmapData SourceBData);
            byte* SourcePointer = (byte*)SourceIntPtr.ToPointer(); //原图像的指针
            int SStride = SourceBData.Stride;

            Stack<Location> FloodStack = new Stack<Location>();
            Location location = new Location
            {
                X = 0,
                Y = 0
            };
            FloodStack.Push(location);

            while (FloodStack.Count > 0)
            {
                Location FLocal = FloodStack.Pop();
                SourcePointer[FLocal.Y * SStride + FLocal.X] = DPValue;

                if (FLocal.X > 0 && SourcePointer[FLocal.Y * SStride + (FLocal.X - 1)] == BGValue)
                {
                    SourcePointer[FLocal.Y * SStride + (FLocal.X - 1)] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X - 1,
                        Y = FLocal.Y
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.X < SWidth - 1 && SourcePointer[FLocal.Y * SStride + (FLocal.X + 1)] == BGValue)
                {
                    SourcePointer[FLocal.Y * SStride + (FLocal.X + 1)] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X + 1,
                        Y = FLocal.Y
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.Y > 0 && SourcePointer[(FLocal.Y - 1) * SStride + FLocal.X] == BGValue)
                {
                    SourcePointer[(FLocal.Y - 1) * SStride + FLocal.X] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X,
                        Y = FLocal.Y - 1
                    };
                    FloodStack.Push(Innerlocation);
                }

                if (FLocal.Y < SHeight - 1 && SourcePointer[(FLocal.Y + 1) * SStride + FLocal.X] == BGValue)
                {
                    SourcePointer[(FLocal.Y + 1) * SStride + FLocal.X] = DPValue;
                    Location Innerlocation = new Location
                    {
                        X = FLocal.X,
                        Y = FLocal.Y + 1
                    };
                    FloodStack.Push(Innerlocation);
                }
            }

            FloodStack.Clear(); // 清空栈内内容。
            maskPaddingImg.UnlockBits(SourceBData);
            return maskPaddingImg;
        }


        public Bitmap FillImageHole(Bitmap SourceBmap)
        {
            byte InsetValue = 127;
            byte BackGroundValu = 0;

            int ExpandOffset = 1;
            int SWidth = SourceBmap.Width;
            int SHeight = SourceBmap.Height;

            Bitmap SingleImg = GetSingleGrayImg(SWidth, SHeight);
            Bitmap PaddingImg = ImgEdgePadding(SourceBmap, ExpandOffset, 0);

            ConvertSingleImg(PaddingImg, SingleImg, ExpandOffset);
            Bitmap FloodFillImg = FloodFill(SingleImg, InsetValue, BackGroundValu, true); // 返回单通道图像。
            PixelInversion(FloodFillImg);
            return FloodFillImg;
        }

        private unsafe void ConvertSingleImg(Bitmap SourceBmap, Bitmap DestBmap, int ExpandOffset)
        {
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceBmap, out BitmapData SBData);
            byte* SPointer = (byte*)SPtr.ToPointer();
            int SWidth = SourceBmap.Width;
            int SHeight = SourceBmap.Height;
            int SStride = SBData.Stride;

            IntPtr DPtr = getIntPtr.GetImgIntPtr(DestBmap, out BitmapData DBData);
            byte* DPointer = (byte*)DPtr.ToPointer();
            int DWidth = DestBmap.Width;
            int DHeight = DestBmap.Height;
            int DStride = DBData.Stride;


            int SOffset = 0;
            int DOffset = 0;
            for (int i = 0; i < DHeight; i++)
            {
                for (int j = 0; j < DStride; j++)
                {
                    SOffset = (i+ ExpandOffset) * SStride + (j+ ExpandOffset) * 3;
                    DOffset = i * DStride + j;
                    DPointer[DOffset] = SPointer[SOffset];
                }
            }
            SourceBmap.UnlockBits(SBData);
            DestBmap.UnlockBits(DBData);
        }


        /// <summary>
        /// Single channel image Pixels the inversion.
        /// Convert pixel value 0 to 255;
        /// </summary>
        /// <param name="SourceImg">Source image.</param>
        private unsafe void PixelInversion(Bitmap SourceImg)
        {
            IntPtr SourcePtr = getIntPtr.GetImgIntPtr(SourceImg, out BitmapData SimgBdata);
            byte* SPointer = (byte*)SourcePtr.ToPointer();
            int SWidth = SourceImg.Width;
            int SHeight = SourceImg.Height;
            int SStride = SimgBdata.Stride;

            int Offset = 0;
            for (int i = 0; i < SHeight; i++)
            {
                for (int j = 0; j < SWidth; j++)
                {
                    Offset = i * SStride + j;
                    if (SPointer[Offset]==127)
                    {
                        SPointer[Offset] = 0;
                    }
                    else if (SPointer[Offset] == 0)
                    {
                        SPointer[Offset] = 255;
                    }
                }
            }
            SourceImg.UnlockBits(SimgBdata);
        }
    }
}
