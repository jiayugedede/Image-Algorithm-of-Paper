﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace test.utils
{
    public class GetImageByteArray
    {
        public GetImageByteArray()
        {
        }

        /// <summary>
        /// Gets the image array.
        /// </summary>
        /// <returns>The image array.</returns>
        /// <m name="SourceBmap">Source bmap.</m>
        public static byte[] GetImageArray(Bitmap SourceBmap)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceBmap, out BitmapData SBdata);

            int SStride = SBdata.Stride;
            int SHeight = SourceBmap.Height;
            int SWidth = SourceBmap.Width;

            int ArraySize = SHeight * SStride;
            byte[] ImageArray = new byte[ArraySize];

            Marshal.Copy(SBdata.Scan0, ImageArray, 0, ArraySize);

            SourceBmap.UnlockBits(SBdata);
            return ImageArray;
        }

        /// <summary>
        /// Gets the image array and Stride from BitmapData.
        /// </summary>
        /// <returns>The image array.</returns>
        /// <m name="SourceBmap">Source bmap.</m>
        /// <m name="SStride">SS tride.</m>
        public static byte[] GetImageArray(Bitmap SourceBmap, out int SStride)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceBmap, out BitmapData SBdata);

            SStride = SBdata.Stride;
            int SHeight = SourceBmap.Height;
            int SWidth = SourceBmap.Width;

            int ArraySize = SHeight * SStride;
            byte[] ImageArray = new byte[ArraySize];

            Marshal.Copy(SBdata.Scan0, ImageArray, 0, ArraySize);

            SourceBmap.UnlockBits(SBdata);
            return ImageArray;
        }



        /// <summary>
        /// Gets the image array and Stride from BitmapData.
        /// </summary>
        /// <returns>The image array.</returns>
        /// <m name="SourceBmap">Source bmap.</m>
        /// <m name="SBdata">SB data.</m>
        /// <m name="SStride">SS tride.</m>
        public static byte[] GetImageArray(Bitmap SourceBmap, out BitmapData SBdata, out int SStride)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr SPtr = getIntPtr.GetImgIntPtr(SourceBmap, out SBdata);

            SStride = SBdata.Stride;
            int SHeight = SourceBmap.Height;
            int SWidth = SourceBmap.Width;

            int ArraySize = SHeight * SStride;
            byte[] ImageArray = new byte[ArraySize];

            Marshal.Copy(SBdata.Scan0, ImageArray, 0, ArraySize);

            SourceBmap.UnlockBits(SBdata);
            return ImageArray;
        }


        public unsafe static bool[][] ImageToBool(Bitmap img)
        {

            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr Ptr = getIntPtr.GetImgIntPtr(img, out BitmapData Bdata);
            int Width = img.Width;
            int Height = img.Height;
            int Stride = Bdata.Stride;
            bool[][] Record = new bool[Height][];
            //int Offset = 0;
            byte* Pointer = (byte*)Ptr.ToPointer();
            for (int i = 0; i < Height; i++)
            {
                Record[i] = new bool[Width];
                for (int j = 0; j < Width; j++)
                {
                    if (Pointer[i * Stride + j] == 255)
                    {
                        Record[i][j] = true;
                    }
                    else
                    {
                        Record[i][j] = false;
                    }
                }
            }
            img.UnlockBits(Bdata);
            return Record;
        }
    }
}
