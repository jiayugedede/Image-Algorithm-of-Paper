﻿using System;
namespace test.utils
{
    public class BitWiseNot
    {
        public BitWiseNot()
        {
        }
        public static void BitwiseNot(int[] Array)
        {
            for (int i = 0; i < Array.Length; i++)
            {
                Array[i] = ~Array[i]+1;
            }
        }
    }
}
