﻿using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace test.utils
{
    public class CreateGrayBitmap
    {
        public CreateGrayBitmap()
        {
        }


        /// <summary>
        /// Creates the gray bitmap. 使用调色板。
        /// </summary>
        /// <returns>The gray bitmap.</returns>
        /// <param name="Width">Width.</param>
        /// <param name="Height">Height.</param>
        public Bitmap GetGrayBitmap(int Width, int Height)
        {
            Bitmap Bmp = new Bitmap(Width, Height, PixelFormat.Format8bppIndexed);
            ColorPalette Pal = Bmp.Palette;
            for (int Y = 0; Y < Pal.Entries.Length; Y++) Pal.Entries[Y] = Color.FromArgb(255, Y, Y, Y);
            Bmp.Palette = Pal;
            return Bmp;
        }

        public static Bitmap StaticGetGrayBitmap(int Width, int Height)
        {
            Bitmap Bmp = new Bitmap(Width, Height, PixelFormat.Format8bppIndexed);
            ColorPalette Pal = Bmp.Palette;
            for (int Y = 0; Y < Pal.Entries.Length; Y++) Pal.Entries[Y] = Color.FromArgb(255, Y, Y, Y);
            Bmp.Palette = Pal;
            return Bmp;
        }

    }
}
