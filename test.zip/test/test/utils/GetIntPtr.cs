﻿using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace test.utils
{
    public class GetIntPtr
    {
        public GetIntPtr()
        {
        
        }
        public IntPtr GetImgIntPtr(Bitmap bitmap)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData NewbitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            IntPtr NewintPtr = NewbitmapData.Scan0;
            return NewintPtr;
        }

        public IntPtr GetImgIntPtr(Bitmap bitmap, out BitmapData bitmapData)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            bitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            IntPtr NewintPtr = bitmapData.Scan0;
            return NewintPtr;
        }

        public BitmapData GetImgBmapData(Bitmap bitmap)
        {
            Rectangle Newrectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData bitmapData = bitmap.LockBits(Newrectangle, ImageLockMode.ReadWrite, bitmap.PixelFormat);
            return bitmapData;
        }
    }
}
