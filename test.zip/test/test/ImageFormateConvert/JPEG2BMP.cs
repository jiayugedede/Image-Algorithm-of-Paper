﻿using System;
using System.Drawing;
using System.IO;

namespace test.ImageFormateConvert
{
    public class JPEG2BMP
    {
        public JPEG2BMP()
        {
        }

        public Bitmap Convort2BMP(string fileName)
        {
            Bitmap bitmap;
            using (Stream bmpStream = System.IO.File.Open(fileName, System.IO.FileMode.Open))
            {
                Image image = Image.FromStream(bmpStream);
                bitmap = new Bitmap(image);
            }
            return bitmap;
         }
    }
}
