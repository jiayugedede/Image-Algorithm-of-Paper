﻿using System;
using Gtk;
using System.Drawing;
using System.Drawing.Imaging;
using Gdk;
using test.utils;
using test.ImageFormateConvert;
using test.NetworkAlgorithm;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using test.GaussFilter;
using test.Filter;
using test.BinaryThreshold;
using test.HoughTransform;
using static test.HoughTransform.HoughTransform;

public partial class MainWindow : Gtk.Window
{
    string log_path = "/home/sam/图片/ExperimentImg/log.txt";
    Tools tools = new Tools();
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
        CreateGrayBitmap createGrayBitmap = new CreateGrayBitmap();
        string Path = "/home/sam/图片/ExperimentImg/BasketballBaby.jpeg";
        var buffer = System.IO.File.ReadAllBytes(Path);
        ImagePool.SourceImage = new Bitmap(Path);
        var pixbuf = new Gdk.Pixbuf(buffer);
        ResultImage.Pixbuf = pixbuf;
        SourceImage.Pixbuf = pixbuf;
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

    protected void OnLoadImageClicked(object sender, EventArgs e)
    {
        using (FileChooserDialog chooser =
    new FileChooserDialog(null,
                          "Select document to open...",
                          null,
                          FileChooserAction.Open,
                          "Open Selected File",
                          ResponseType.Accept,
                          "Discard & Return to Main Page",
                          ResponseType.Cancel))
        {
            if (chooser.Run() == (int)ResponseType.Accept)
            {
                /*
                //System.IO.StreamReader file = System.IO.File.OpenText(chooser.Filename);
                var buffer = System.IO.File.ReadAllBytes(chooser.Filename);
                var pixbuf = new Gdk.Pixbuf(buffer);
                SourceImage.Pixbuf = pixbuf;
                */
                ImagePool.ImagePath = chooser.Filename;

            }
        }
        try
        {
            Bitmap JBitmap = new Bitmap(ImagePool.ImagePath);
            Bitmap IllustatingImage = (Bitmap)JBitmap.Clone();//
            byte[] SImageStream = ImageToByte(JBitmap);

            Pixbuf SImagePixbuf = new Pixbuf(SImageStream); //1号图片框原图加载
            SourceImage.Pixbuf = SImagePixbuf;
           
            Stopwatch sw = new Stopwatch();
            sw.Start();
            ConvertSingleChannel SingleChannel = new ConvertSingleChannel(); //三通道转单通道
            Bitmap singleChannel=null;

            if (JBitmap.PixelFormat==PixelFormat.Format32bppArgb || JBitmap.PixelFormat == PixelFormat.Format32bppPArgb ||
            JBitmap.PixelFormat == PixelFormat.Format32bppRgb)
            {
                singleChannel = SingleChannel.Convert4ToSingleChannel(JBitmap);
            }
            else if (JBitmap.PixelFormat == PixelFormat.Format24bppRgb)
            {
                singleChannel = SingleChannel.Convert3ToSingleChannel(JBitmap);
            }

            GaussSmoothen gaussSmoothen = new GaussSmoothen();
            Bitmap SmoothenImg = gaussSmoothen.DoGaussSmoothen(singleChannel, 3, 65535);

            //SmoothenImg.Save("/home/sam/桌面/SmoothenImg.bmp", ImageFormat.Bmp);

            SobelFilter sobelFilter = new SobelFilter();
            Bitmap SobelImg = sobelFilter.DoSobel(SmoothenImg);
            //SobelImg.Save("/home/sam/桌面/Sobel.bmp", ImageFormat.Bmp);
            Otsu otsu = new Otsu();
            Bitmap SobelCopy = (Bitmap)SobelImg.Clone();
            int OtsuThreshold = otsu.getOtsuThreshold(SobelCopy);
            otsu.threshold(SobelCopy, OtsuThreshold);

            //SobelCopy.Save("/home/sam/桌面/otsu.bmp", ImageFormat.Bmp);

            Bitmap ColorSobel = SingleChannel.Convert1To3Channel(SobelCopy);

            //ColorSobel.Save("/home/sam/桌面/Hough1.bmp", ImageFormat.Bmp);
            HoughLineTransform2 houghLineTransform2 = new HoughLineTransform2();
            houghLineTransform2.Dohough(ColorSobel);
            
            sw.Stop();
            TimeSpan ts2 = sw.Elapsed;
            Tools.WriteByLine(log_path, "Padding Pointer:" + ts2.TotalMilliseconds.ToString());

            byte[] ImageStream = ImageToByte(ColorSobel);
            Pixbuf ImagePixbuf = new Pixbuf(ImageStream);
            ResultImage.Pixbuf = ImagePixbuf;
            Console.ReadKey();
        }
        catch (Exception ex)
        {
            Tools.WriteByLine(log_path, ex.Message.ToString());
            Console.WriteLine(ex.ToString());
        }
    }

    public Pixbuf GetAppointPixbuf(Bitmap SourceImage, int Index)
    {
        string path = "/home/samzhang/图片/temp" + Index.ToString() + ".bmp";
        SourceImage.Save(path, ImageFormat.Bmp);
        byte[] buffer = System.IO.File.ReadAllBytes(path);
        Pixbuf pixbuf = new Gdk.Pixbuf(buffer);
        return pixbuf;
    }

    /*
           byte[] ImageStream = ImageToByte(GrayResizeBitmap);
           Pixbuf ImagePixbuf = new Pixbuf(ImageStream);
           ResultImage.Pixbuf = ImagePixbuf;   
     */
    public static byte[] ImageToByte(Bitmap SourceImg)
    {
        using(var stream = new MemoryStream())
        {
            SourceImg.Save(stream, ImageFormat.Png);
            return stream.ToArray();
        }
    }

    public Bitmap DoFillHole(Bitmap bitmap)
    {
        GrayScaleOneChannel grayScaleOneChannel = new GrayScaleOneChannel();
        Bitmap OneChannel = grayScaleOneChannel.ConvertToGrayBitmap(bitmap);

        test.NetworkAlgorithm.FillHole fillHole = new test.NetworkAlgorithm.FillHole();
        fillHole.FillHoleAlgorithm(OneChannel, true);
        return OneChannel;
    }

}

