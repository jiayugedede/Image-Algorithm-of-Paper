﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.utils;

namespace test.GaussFilter
{
    public class GaussSmoothen
    {
        public GaussSmoothen()
        {
        }
        public double[,] CreateGaussKernel(int KernelRadio=3, double StandardDeviation=0.5)
        {
            double[,] GaussKernel = new double[KernelRadio,KernelRadio];
            if (Math.Abs(StandardDeviation) < 1e-9)
            {
                StandardDeviation = ((KernelRadio - 1) * 0.5 - 1) * 0.3 + 0.8;
            }

            if (Math.Abs(KernelRadio) < 1e-9)
            {
                KernelRadio = Convert.ToInt32(2 * Math.Ceiling(3 * StandardDeviation) + 1);
            }

            double Quadratic = 2 * (StandardDeviation * StandardDeviation);
            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            int CenterX = (KernelRadio - 1) / 2;
            double sum = 0d;
            Parallel.For(0, KernelRadio, options, i => {
                for (int j = 0; j < KernelRadio; j++)
                {
                    int IndexI = i - CenterX;
                    int IndexJ = j - CenterX;
                    GaussKernel[i, j] = Math.Exp(-(IndexI * IndexI + IndexJ * IndexJ) / Quadratic)/(Math.PI* Quadratic);
                    sum += GaussKernel[i, j];
                }
            });
            sum = 1 / sum;
            Parallel.For(0, KernelRadio, options, i=>{
                for (int j = 0; j < KernelRadio; j++)
                {
                    GaussKernel[i, j] *= sum;
                }
            });
            return GaussKernel;
        }

        /// <summary>
        /// Dos the gauss smoothen. Only gray-scale image.
        /// </summary>
        /// <returns>The gauss smoothen.</returns>
        /// <param name="SourceImg">Source image.</param>
        /// <param name="KernelRadio">Kernel radio must be odd number.</param>
        /// <param name="StandardDeviation">Standard deviation.</param>
        public unsafe Bitmap DoGaussSmoothen(Bitmap SourceImg, int KernelRadio=3, double StandardDeviation=0.5)
        {
            if (SourceImg.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                return null;
            }
            double[,] templateMatrix = CreateGaussKernel(KernelRadio, StandardDeviation);//生成高斯核卷积模板

            int KernelLength = templateMatrix.GetLength(0);
            int StartOffset = (KernelLength - 1) / 2;
            PaddingEdge paddingEdge = new PaddingEdge();
            SourceImg = paddingEdge.PaddingImgEdge1Channel(SourceImg, StartOffset);

            GetIntPtr GetPtr = new GetIntPtr();
            IntPtr SourceintPtr = GetPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* SourcePointer = (byte*)SourceintPtr.ToPointer();

            int Width = SourceImg.Width;
            int Height = SourceImg.Height;
            int ImageOffset = SBdata.Stride;//图像在每行像素的数据跨度的具体数值

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            for (int i = StartOffset; i < Height-StartOffset; i++)
            {
                for (int j = StartOffset; j < Width - StartOffset; j++)
                {
                    int InnerX = 0, InnerY = 0;
                    double InnerSum = 0;
                    for (int k = i - StartOffset; k <= i + StartOffset; k++)
                    {
                        for (int q = j - StartOffset; q <= j + StartOffset; q++)
                        {
                            // 在这里累加
                            InnerSum += SourcePointer[k * ImageOffset + q] * templateMatrix[InnerX, InnerY++];

                        }
                        InnerY = 0;
                        InnerX++;
                    }

                    SourcePointer[i * ImageOffset + j] = Convert.ToByte(InnerSum / KernelRadio * KernelRadio);
                }
            }

            SourceImg.UnlockBits(SBdata);
            System.Drawing.Rectangle rectangle = new System.Drawing.Rectangle(StartOffset, StartOffset, SourceImg.Width-2* StartOffset, SourceImg.Height-2* StartOffset);
            Bitmap CroppedImg = paddingEdge.Cut1CImg(SourceImg, rectangle);
            return CroppedImg;
        }
    }
}
