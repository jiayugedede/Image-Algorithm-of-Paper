﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.utils;

namespace test.Filter
{
    public class SobelFilter
    {
        public SobelFilter()
        {
        }

        public struct Gradient 
        {
            public Point location;
            public double localGradient;
        }


        //public int[,] SobelHorizontal = { { 1, 0, -1 },{ 2, 0, -2 }, { 1, 0, -1 } };
        //public int[,] SobelVertical = { { 1, 2, 1} ,{0, 0, 0} ,{ -1, -2, -1}};

        //斜率正无穷-->垂直向上，斜率负无穷-->水平。
        public unsafe Bitmap DoSobel(Bitmap SourceImg)
        {

            int Scale = 4;
            if (SourceImg.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                return null;
            }
            //double[,] templateMatrix = CreateGaussKernel(KernelRadio, StandardDeviation);//生成高斯核卷积模板
            double[,] SobelHorizontal = { { 1, 0, -1 }, 
                                          { 1, 0, -1 }, 
                                          { 1, 0, -1 } };
            double[,] SobelVertical = { { 1, 1, 1 }, 
                                        { 0, 0, 0 }, 
                                        { -1, -1, -1 } };

            int KernelSize = SobelHorizontal.GetLength(0);
            int StartOffset = (SobelHorizontal.GetLength(0) - 1) / 2;
            PaddingEdge paddingEdge = new PaddingEdge();
            StartOffset *= Scale;
            SourceImg = paddingEdge.PaddingImgEdge1Channel(SourceImg, StartOffset);
            //SourceImg.Save(@"/home/sam/文档/Tencent Files/1483956702/FileRecv/PA1/SourceImg.bmp", ImageFormat.Bmp);

            GetIntPtr GetPtr = new GetIntPtr();
            IntPtr SourceintPtr = GetPtr.GetImgIntPtr(SourceImg, out BitmapData SBdata);
            byte* SourcePointer = (byte*)SourceintPtr.ToPointer();

            int Width = SourceImg.Width;
            int Height = SourceImg.Height;
            int ImageOffset = SBdata.Stride;//图像在每行像素的数据跨度的具体数值

            double[,] DerivativeX = new double[Height, Width];
            double[,] DerivativeY = new double[Height, Width];
            double[,] GradientArray = new double[Height, Width];

            CreateGrayBitmap CreateGray = new CreateGrayBitmap();
            Bitmap DestImg = CreateGray.GetGrayBitmap(SourceImg.Width, SourceImg.Height);
            IntPtr DestintPtr = GetPtr.GetImgIntPtr(DestImg, out BitmapData DBdata);
            int DestOffset = DBdata.Stride;
            byte* DestPointer = (byte*)DestintPtr.ToPointer();
            try
            {
                for (int i = 1; i < Height - 1; i++)
                {
                    for (int j = 1; j < Width - 1; j++)
                    {
                        int InnerX = 0, InnerY = 0;
                        double InnerSumY = 0, InnerSumX = 0;

                        for (int k = i - StartOffset / Scale; k <= i + StartOffset / Scale; k++)
                        {
                            for (int q = j - StartOffset / Scale; q <= j + StartOffset / Scale; q++)
                            {
                                // 在这里累加
                                InnerSumX += SourcePointer[k * ImageOffset + q] * SobelHorizontal[InnerX, InnerY];
                                InnerSumY += SourcePointer[k * ImageOffset + q] * SobelVertical[InnerX, InnerY];
                                InnerY++;
                            }
                            InnerY = 0;
                            InnerX++;
                        }

                        DerivativeX[i, j] = InnerSumX;
                        DerivativeY[i, j] = InnerSumY;

                        try
                        {
                            double gradientValue = Math.Sqrt(InnerSumY * InnerSumY + InnerSumX * InnerSumX);
                            GradientArray[i, j] = gradientValue;

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Looping error --"+ex.ToString());
            }

           try
            {
                double[,] ResultImg = NMS(Width, Height, KernelSize,
                    GradientArray, DerivativeX, DerivativeY);

                for (int i = 0; i < Height; i++)
                {
                    for (int j = 0; j < Width; j++)
                    {
                        if (ResultImg[i, j] >= 255)
                        {
                            ResultImg[i, j] = 255;
                        }
                        byte PixelValue = Convert.ToByte(ResultImg[i, j]);
                        DestPointer[i * DestOffset + j] = PixelValue;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


            SourceImg.UnlockBits(SBdata);
            DestImg.UnlockBits(DBdata);

            //剪切图片
            Rectangle rectangle = new Rectangle(StartOffset, StartOffset, DestImg.Width - 2 * StartOffset, DestImg.Height - 2 * StartOffset);
            Bitmap CroppedImg = paddingEdge.Cut1CImg(DestImg, rectangle);
            return CroppedImg;
        }

        /// <summary>
        /// Nms the specified Width, Height, KernelSize, Gradient, DerivativeX and DerivativeY.
        /// 非极大值抑制
        /// </summary>
        /// <returns>The nms.</returns>
        /// <param name="Width">Width.</param>
        /// <param name="Height">Height.</param>
        /// <param name="KernelSize">Kernel size.</param>
        /// <param name="Gradient">Gradient.</param>
        /// <param name="DerivativeX">Derivative x.</param>
        /// <param name="DerivativeY">Derivative y.</param>
        public double[,] NMS(int Width, int Height, int KernelSize, 
            double[,] Gradient, double[,] DerivativeX, double[,] DerivativeY)
        {
            // Perform Non maximum suppression:
            // NonMax = Gradient;
            int i, j;
            int Limit;
            if (KernelSize%2 !=0)
            {
                Limit = KernelSize / 2; 
            }
            else
            {
                Limit = KernelSize / 2;
            }

            float Tangent;
            double[,] NonMax = new double[Height, Width];

            try
            {
                for (i = 0; i <= (Height - 1); i++)
                {
                    for (j = 0; j <= (Width - 1); j++)
                    {
                        NonMax[i, j] = Gradient[i, j];
                    }
                }
                for (i = Limit; i <= (Height - Limit) - 1; i++)
                {
                    for (j = Limit; j <= (Width - Limit) - 1; j++)
                    {
                        if (Math.Abs(DerivativeX[i, j]) < 1e-9)
                            Tangent = 90F;
                        else
                            Tangent = (float)(Math.Atan(DerivativeY[i, j] / DerivativeX[i, j]) * 180 / Math.PI); //rad to degree

                        //Horizontal Edge
                        if (((-22.5 < Tangent) && (Tangent <= 22.5)) || ((157.5 < Tangent) && (Tangent <= -157.5)))
                        {
                            if ((Gradient[i, j] < Gradient[i, j + 1]) || (Gradient[i, j] < Gradient[i, j - 1]))
                                NonMax[i, j] = 0;
                        }


                        //Vertical Edge
                        if (((-112.5 < Tangent) && (Tangent <= -67.5)) || ((67.5 < Tangent) && (Tangent <= 112.5)))
                        {
                            if ((Gradient[i, j] < Gradient[i + 1, j]) || (Gradient[i, j] < Gradient[i - 1, j]))
                                NonMax[i, j] = 0;
                        }

                        //+45 Degree Edge
                        if (((-67.5 < Tangent) && (Tangent <= -22.5)) || ((112.5 < Tangent) && (Tangent <= 157.5)))
                        {
                            if ((Gradient[i, j] < Gradient[i + 1, j - 1]) || (Gradient[i, j] < Gradient[i - 1, j + 1]))
                                NonMax[i, j] = 0;
                        }

                        //-45 Degree Edge
                        if (((-157.5 < Tangent) && (Tangent <= -112.5)) || ((67.5 < Tangent) && (Tangent <= 22.5)))
                        {
                            if ((Gradient[i, j] < Gradient[i + 1, j + 1]) || (Gradient[i, j] < Gradient[i - 1, j - 1]))
                                NonMax[i, j] = 0;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("NMS--"+ex.ToString());
            }
            return NonMax;
        }



//                //PostHysteresis = NonMax;
//                for (r = Limit; r <= (Width - Limit) - 1; r++)
//                {
//                    for (c = Limit; c <= (Height - Limit) - 1; c++)
//                    {

//                        PostHysteresis[r, c] = (int) NonMax[r, c];
//    }

//}
//        //Find Max and Min in Post Hysterisis
//        float min, max;
//        min = 100;
//                max = 0;
//                for (r = Limit; r <= (Width - Limit) - 1; r++)
//                    for (c = Limit; c <= (Height - Limit) - 1; c++)
//                    {
//                        if (PostHysteresis[r, c] > max)
//                        {
//                            max = PostHysteresis[r, c];
//                        }

//                        if ((PostHysteresis[r, c] < min) && (PostHysteresis[r, c] > 0))
//                        {
//                            min = PostHysteresis[r, c];
//                        }
//                    }



//                for (r = Limit; r <= (Width - Limit) - 1; r++)
//                {
//                    for (c = Limit; c <= (Height - Limit) - 1; c++)
//                    {
//                        if (PostHysteresis[r, c] >= MaxHysteresisThresh)
//                        {

//                            EdgePoints[r, c] = 1;
//                            GNH[r, c] = 255;
//                        }
//                        if ((PostHysteresis[r, c] < MaxHysteresisThresh) && (PostHysteresis[r, c] >= MinHysteresisThresh))
//                        {

//                            EdgePoints[r, c] = 2;
//                            GNL[r, c] = 255;

//                        }

//                    }

//                }

//                HysterisisThresholding(EdgePoints);

//                for (i = 0; i <= (Width - 1); i++)
//                    for (j = 0; j <= (Height - 1); j++)
//                    {
//                        EdgeMap[i, j] = EdgeMap[i, j] * 255;
//                    }

//                return;

//            }
//public void HysterisisThresholding(int[,] Edges)
//{

//    int i, j;
//    int Limit = KernelSize / 2;

//    for (i = Limit; i <= (Width - 1) - Limit; i++)
//        for (j = Limit; j <= (Height - 1) - Limit; j++)
//        {
//            if (Edges[i, j] == 1)
//            {
//                EdgeMap[i, j] = 1;

//            }

//        }

//    for (i = Limit; i <= (Width - 1) - Limit; i++)
//    {
//        for (j = Limit; j <= (Height - 1) - Limit; j++)
//        {
//            if (Edges[i, j] == 1)
//            {
//                EdgeMap[i, j] = 1;
//                Travers(i, j);
//                VisitedMap[i, j] = 1;
//            }
//        }
//    }




//    return;
//}



//private void Travers(int X, int Y)
//{


//    if (VisitedMap[X, Y] == 1)
//    {
//        return;
//    }

//    //1
//    if (EdgePoints[X + 1, Y] == 2)
//    {
//        EdgeMap[X + 1, Y] = 1;
//        VisitedMap[X + 1, Y] = 1;
//        Travers(X + 1, Y);
//        return;
//    }
//    //2
//    if (EdgePoints[X + 1, Y - 1] == 2)
//    {
//        EdgeMap[X + 1, Y - 1] = 1;
//        VisitedMap[X + 1, Y - 1] = 1;
//        Travers(X + 1, Y - 1);
//        return;
//    }

//    //3

//    if (EdgePoints[X, Y - 1] == 2)
//    {
//        EdgeMap[X, Y - 1] = 1;
//        VisitedMap[X, Y - 1] = 1;
//        Travers(X, Y - 1);
//        return;
//    }

//    //4

//    if (EdgePoints[X - 1, Y - 1] == 2)
//    {
//        EdgeMap[X - 1, Y - 1] = 1;
//        VisitedMap[X - 1, Y - 1] = 1;
//        Travers(X - 1, Y - 1);
//        return;
//    }
//    //5
//    if (EdgePoints[X - 1, Y] == 2)
//    {
//        EdgeMap[X - 1, Y] = 1;
//        VisitedMap[X - 1, Y] = 1;
//        Travers(X - 1, Y);
//        return;
//    }
//    //6
//    if (EdgePoints[X - 1, Y + 1] == 2)
//    {
//        EdgeMap[X - 1, Y + 1] = 1;
//        VisitedMap[X - 1, Y + 1] = 1;
//        Travers(X - 1, Y + 1);
//        return;
//    }
//    //7
//    if (EdgePoints[X, Y + 1] == 2)
//    {
//        EdgeMap[X, Y + 1] = 1;
//        VisitedMap[X, Y + 1] = 1;
//        Travers(X, Y + 1);
//        return;
//    }
//    //8

//    if (EdgePoints[X + 1, Y + 1] == 2)
//    {
//        EdgeMap[X + 1, Y + 1] = 1;
//        VisitedMap[X + 1, Y + 1] = 1;
//        Travers(X + 1, Y + 1);
//        return;
//    }


//    //VisitedMap[X, Y] = 1;
//    return;
//}
    }
}
