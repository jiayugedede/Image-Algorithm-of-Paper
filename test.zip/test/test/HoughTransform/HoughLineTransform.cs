﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using test.utils;

namespace test.HoughTransform
{
    public static class HoughTransform
    {
        public static int GlobalTheta = 0;
        public static int GlobalrAxisSize = 0;
        public static int GlobalHalfRAxisSize = 0;
        public static int GlobalMaxRadius = 0;
        public static int GlobalHeight = 0;

        public static int RightMove(int value, int pos)
        {
            if (pos != 0)
            {
                int mask = int.MaxValue;
                value = value >> 1; // 右移等于原数除以2
                value = value & mask;
                value = value >> pos - 1;
            }
            return value;
        }

        public static ArrayData houghTransform(ArrayData inputData, int thetaAxisSize, int rAxisSize, int minContrast)
        {
            thetaAxisSize = 180;
            int width = inputData.width;
            int height = inputData.height;
            int maxRadius = (int)Math.Ceiling(Math.Sqrt(width * width + height * height));
            int HoughHeight = (int)(Math.Sqrt(2)* Math.Max(height, width)/2);
            int halfRAxisSize = RightMove(rAxisSize, 1); //无符号右移

            GlobalMaxRadius = maxRadius;
            GlobalHalfRAxisSize = halfRAxisSize;

            ArrayData outputData = new ArrayData(thetaAxisSize, rAxisSize);

            // x output ranges from 0 to pi
            // y output ranges from -maxRadius to maxRadius
            double[] sinTable = new double[thetaAxisSize];
            double[] cosTable = new double[thetaAxisSize];
            for (int theta = thetaAxisSize - 1; theta >= 0; theta--)
            {
                double thetaRadians = theta * Math.PI / thetaAxisSize;
                sinTable[theta] = Math.Sin(thetaRadians);
                cosTable[theta] = Math.Cos(thetaRadians);
            }

            int centerX = width / 2;
            int centerY = height / 2;
            try
            {
                for (int y = height - 1; y >= 0; y--)
                {
                    for (int x = width - 1; x >= 0; x--)
                    {
                        if (inputData.contrast(x, y, minContrast))
                        {
                            for (int theta = thetaAxisSize - 1; theta >= 0; theta--)
                            {
                                double r = cosTable[theta] * (x - centerX) + sinTable[theta] * (y - centerY);
                                //int rScaled = (int)Math.Round(r * halfRAxisSize / maxRadius) + halfRAxisSize;
                                int rScaled = Convert.ToInt32(r + HoughHeight);
                                outputData.accumulate(theta, rScaled, 1);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            return outputData;
        }

        public class ArrayData
        {
            public int[] dataArray;
            public int width;
            public int height;

            public ArrayData(int width, int height) : this(new int[width * height], width, height)
            {

            }

            public ArrayData(int[] dataArray, int width, int height)
            {
                this.dataArray = dataArray;
                this.width = width;
                this.height = height;
            }

            public int[] getArray()
            {
                return dataArray;
            }

            public int get(int x, int y)
            { return dataArray[y * width + x]; }

            public void set(int x, int y, int value)
            { dataArray[y * width + x] = value; }

            public void accumulate(int x, int y, int delta)
            { set(x, y, get(x, y) + delta); }

            public bool contrast(int x, int y, int minContrast)
            {
                int centerValue = get(x, y);
                for (int i = 8; i >= 0; i--)
                {
                    if (i == 4)
                        continue;
                    int newx = x + (i % 3) - 1;
                    int newy = y + (i / 3) - 1;
                    if ((newx < 0) || (newx >= width) || (newy < 0) || (newy >= height))
                        continue;
                    if (Math.Abs(get(newx, newy) - centerValue) >= minContrast)
                        return true;
                }
                return false;
            }

            public int getMax()
            {
                int max = dataArray[0];
                for (int i = width * height - 1; i > 0; i--)
                    if (dataArray[i] > max)
                        max = dataArray[i];
                return max;
            }
        }

        /// <summary>
        /// Gets the array data from image.
        /// </summary>
        /// <returns>The array data from image.</returns>
        /// <param name="inputImage">Input image.</param>
        public unsafe static ArrayData getArrayDataFromImage(Bitmap inputImage)
        {
            int width = inputImage.Width;
            int height = inputImage.Height;

            GetIntPtr GetPtr = new GetIntPtr();
            IntPtr SourceintPtr = GetPtr.GetImgIntPtr(inputImage, out BitmapData SBdata);
            byte* SourcePointer = (byte*)SourceintPtr.ToPointer();

            int offset = SBdata.Stride;

            ArrayData arrayData = new ArrayData(width, height);
            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, height, options, i =>
            {
                for (int x = 0; x < width; x++)
                {
                    int rgbValue = SourcePointer[i * offset + x];
                    arrayData.set(x, height - 1 - i, rgbValue);
                }
            });

            inputImage.UnlockBits(SBdata);
            return arrayData;
        }

        public static (Bitmap, int[,]) writeOutputImage(string filename, ArrayData arrayData)
        {
            int max = arrayData.getMax();
            int[] DataArray = arrayData.getArray();

            (Bitmap, int[,]) HoughTransformImg = PaddingEdge.Array2Image(DataArray, arrayData.width, arrayData.height, max);
            //HoughTransformImg.Save(filename, ImageFormat.Bmp);
            return HoughTransformImg;
        }

        public static List<LocalMaxPeak> StatisticLocalMaxPeak(int[,] arrayData, int Threshold)
        {
            //int[] DataArray = arrayData.getArray();
            //int[] FlipedArray = FilpingArray(DataArray, arrayData.width, arrayData.height);
            List<LocalMaxPeak> localMaxPeaks = FindLocalMaxPeak(arrayData, threshold: Threshold);
            localMaxPeaks.Sort((a,b)=>b.value.CompareTo(a.value));
            return localMaxPeaks;
        }

        /// <summary>
        /// Dos the hough.
        /// </summary>
        /// <param name="bitmap">Bitmap.</param>
        /// <param name="SavePath">Save path.</param>
        /// <param name="thetaAxisSize">Theta axis size.</param>
        /// <param name="rAxisSize">R axis size.</param>
        /// <param name="minContrast">Minimum contrast.</param>
        public static List<LocalMaxPeak> DoHough(Bitmap bitmap, 
            out Bitmap HoughTransformImg, string SavePath, 
            int thetaAxisSize = 640, int rAxisSize = 480, 
            int minContrast = 100, int Threshold =80)
        {
            int width = bitmap.Width;
            int height = bitmap.Height;
            rAxisSize = (int)Math.Ceiling(Math.Sqrt(width * width + height * height));

            ArrayData inputData = getArrayDataFromImage(bitmap);
            ArrayData outputData = houghTransform(inputData, thetaAxisSize, rAxisSize, minContrast);
            (Bitmap, int[,]) HoughTransform = writeOutputImage(SavePath, outputData);
            HoughTransformImg = HoughTransform.Item1;
            int[,] Hough2DArray = HoughTransform.Item2;
            List<LocalMaxPeak> localMaxPeaks = StatisticLocalMaxPeak(Hough2DArray, Threshold);
            return localMaxPeaks;
        }

        public static void Convert2ScaleFast(Bitmap bmp)
        {
            BitmapData bmData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
                    ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            unsafe
            {
                byte* p = (byte*)(void*)bmData.Scan0.ToPointer();
                int stopAddress = (int)p + bmData.Stride * bmData.Height;
                while ((int)p != stopAddress)
                {
                    if (p[0] !=0)
                    {
                        p[0] = 1;
                    }
                    p ++;
                }
            }
            bmp.UnlockBits(bmData);
        }

        public static unsafe void GetHighLight(Bitmap OriginalBmp, Bitmap MaskBmp)
        {
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr OrigIntPtr = getIntPtr.GetImgIntPtr(OriginalBmp, out BitmapData OBdata);
            IntPtr MaskIntptr = getIntPtr.GetImgIntPtr(MaskBmp, out BitmapData DBdata);

            byte* SourcePointer = (byte*)OrigIntPtr.ToPointer();
            byte* MaskPointer = (byte*)MaskIntptr.ToPointer();

            int SourceStride = OBdata.Stride;
            int MaskStride = DBdata.Stride;

            int Width = OriginalBmp.Width;
            int Height = OriginalBmp.Height;

            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            Parallel.For(0, Height, options, i => {
                for (int j = 0; j < Width; j++)
                {
                    SourcePointer[i * SourceStride + j] *= MaskPointer[i * MaskStride + j];
                }
            });

            OriginalBmp.UnlockBits(OBdata);
            MaskBmp.UnlockBits(DBdata);


        }

        public struct LocalMaxPeak {
            public int height;
            public int width;
            public int value;
        }

        /// <summary>
        /// Finds the local max peak.
        /// </summary>
        /// <returns>The local max peak.</returns>
        /// <param name="Array">Array.</param>
        /// <param name="threshold">Threshold.</param>
        public static List<LocalMaxPeak> FindLocalMaxPeak(int[,] Array, int threshold)
        {
            List<LocalMaxPeak> LocalMaxPeakCollection = new List<LocalMaxPeak>();
            int degreeOfParallelism = Environment.ProcessorCount - 1;//获取处理器的数量。
            var options = new ParallelOptions
            {
                MaxDegreeOfParallelism = degreeOfParallelism
            };

            try
            {
                for (int i = 0; i < Array.GetLength(0) - 1; i++)
                {
                    for (int j = 0; j < Array.GetLength(1) - 2; j++)
                    {
   
                        if (Array[i + 1, j+1] > threshold &&
                        Array[i + 1, j + 1] > Array[i + 1, j ] &&
                        Array[i + 1, j + 1] > Array[i + 1, j + 2] &&
                        Array[i + 1, j + 1] > Array[i, j ] &&
                        Array[i + 1, j + 1] >= Array[i+2, j + 2])
                        {
                            LocalMaxPeak localMaxPeak = new LocalMaxPeak
                            {
                                height = i+1,
                                width = j+1,
                                value = Array[i + 1, j + 1]
                            };
                            LocalMaxPeakCollection.Add(localMaxPeak);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hough --" + ex.ToString());
            }


            return LocalMaxPeakCollection;
        }

        /// <summary>
        /// Draws the rectangle on image.
        /// </summary>
        /// <param name="InputImage">Input image.</param>
        /// <param name="localMaxPeak">Local max peak.</param>
        /// <param name="WidowsSize">Widows size.</param>
        public unsafe static void DrawRectangle(Bitmap InputImage, LocalMaxPeak localMaxPeak, int WidowsSize)
        {
            if (InputImage.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                return;
            }
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr InputIntPtr = getIntPtr.GetImgIntPtr(InputImage, out BitmapData SBdata);
            byte* SourcePointer = (byte*)InputIntPtr.ToPointer();

            int Width = InputImage.Width;
            int Height = InputImage.Height;
            int InputStride = SBdata.Stride;

            int HalfWindowsSize = WidowsSize >> 1;

            int locationY = localMaxPeak.height- HalfWindowsSize;
            int localtionX = localMaxPeak.width- HalfWindowsSize;

            for (int i = 0; i < WidowsSize; i++)
            {
                for (int j = 0; j < WidowsSize; j++)
                {
                    int distance = Convert.ToInt32(Math.Sqrt((HalfWindowsSize - i) * (HalfWindowsSize - i) + (HalfWindowsSize - j) * (HalfWindowsSize - j)));
                    if (distance == HalfWindowsSize)
                    {
                        SourcePointer[(locationY + i) * InputStride + (localtionX + j) * 3] = SourcePointer[locationY * InputStride + localtionX * 3 + 1] = 0;
                        SourcePointer[(locationY + i) * InputStride + (localtionX + j) * 3 + 2] = 255;
                    }
                }
            }
            InputImage.UnlockBits(SBdata);
        }



        public unsafe static void DrawLine(Bitmap InputImage, LocalMaxPeak localMaxPeak)
        {
            if (InputImage.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                return;
            }
            GetIntPtr getIntPtr = new GetIntPtr();
            IntPtr InputIntPtr = getIntPtr.GetImgIntPtr(InputImage, out BitmapData SBdata);
            byte* SourcePointer = (byte*)InputIntPtr.ToPointer();


            int Width = InputImage.Width;
            int Height = InputImage.Height;
            int InputStride = SBdata.Stride;

            double theta = localMaxPeak.width *Math.PI / GlobalTheta;
            double rho = (localMaxPeak.height-GlobalHalfRAxisSize) * GlobalMaxRadius / GlobalHalfRAxisSize;

            for (int j = 0; j < Width; j++)
            {
                int y = (int)(Math.Cos(theta) / Math.Sin(theta) * j + rho / Math.Sin(theta));

                if (y >= 0 && y < Height)
                {
                    SourcePointer[y * InputStride + j * 3] = SourcePointer[y * InputStride + j * 3 + 1] = 255;
                    SourcePointer[y * InputStride + j * 3 + 2] = 255;
                }
            }

            InputImage.UnlockBits(SBdata);
        }
    }
}
